import { useEffect, useRef } from "react";

export function useOutsideClick(onOutsideClick?: (event: any) => void) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: any) {
      if (ref.current && !ref.current.contains(event.target)) {
        onOutsideClick?.(event);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [ref]);

  return ref;
}

export function OutsideClicker(props: {
  onOutsideClick?: (event: any) => void;
  children: React.ReactNode;
}) {
  const ref = useOutsideClick(props.onOutsideClick);

  return <div ref={ref}>{props.children}</div>;
}
