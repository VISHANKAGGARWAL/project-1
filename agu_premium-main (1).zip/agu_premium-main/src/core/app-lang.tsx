import i18n from "i18next";
import { initReactI18next, useTranslation } from "react-i18next";
import LanguageDetector from "i18next-browser-languagedetector";

import en from "../assets/_lang/en.json";
import hi from "../assets/_lang/hi.json";
import jp from "../assets/_lang/jp.json";
import { atomWithStorage } from "jotai/utils";
import { useAtom } from "jotai";
import { useEffect } from "react";

const supportedLanguages = ["en", "hi", "jp"];

i18n.use(initReactI18next).init({
  resources: {
    en: {
      translation: en,
    },
    hi: {
      translation: hi,
    },
    jp: {
      translation: jp,
    },
  },
  lng: "en",
  fallbackLng: "en",
  interpolation: {
    escapeValue: false,
  },
});

export const appLang = {
  i18: i18n,
  toggleLang: () => {
    const currentLang = i18n.language;
    const currentLangIndex = supportedLanguages.indexOf(currentLang);
    const nextLangIndex = (currentLangIndex + 1) % supportedLanguages.length;
    const nextLang = supportedLanguages[nextLangIndex];
    i18n.changeLanguage(nextLang);
  },
  changeLang: (lang: typeof supportedLanguages[number]) => {
    i18n.changeLanguage(lang);
  },
};

export function useAppLang() {
  const { t } = useTranslation();
  return t;
}

const languageAtom = atomWithStorage("app-lang", "en");
export const useLanguage = () => useAtom(languageAtom);

export const AppLangProvider = ({
  children,
}: {
  children: React.ReactNode;
}) => {
  const [lang] = useLanguage();

  useEffect(() => {
    appLang.changeLang(lang);
  }, []);

  return <>{children}</>;
};
