import { doc, getFirestore, setDoc, updateDoc } from "firebase/firestore";
import { User } from "./auth.types";

export const createUserInFirestore = async (uid: string, newUser: User) => {
  const docRef = doc(getFirestore(), "users", uid);
  try {
    await setDoc(docRef, newUser);
  } catch (error) {
    console.log(error);
    throw new Error("Error creating user");
  }
};
