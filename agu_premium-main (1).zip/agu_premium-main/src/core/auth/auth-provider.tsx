import React from "react";
import { useAuth } from "./auth-hooks";

export const AuthProvider = (props: {
  children?: React.ReactNode;
  nonAuth?: React.ReactNode;
}) => {
  const auth = useAuth();

  // No User
  if (!auth.user) {
    return <>{props.nonAuth}</>;
  }

  return <>{props.children}</>;
};
