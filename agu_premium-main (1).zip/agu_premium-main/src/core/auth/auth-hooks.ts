import { useEffect, useState } from "react";
import { User as FBUser, onAuthStateChanged, getAuth } from "firebase/auth";
import { User } from "./auth.types";
import { doc, getDoc, getFirestore } from "firebase/firestore";
import {
  useFireCollectionCRUD,
  useFirebaseDocCRUD,
} from "../firebase/providers-hook-new";

export const useAuth = () => {
  const [fbUser, setFbUser] = useState<FBUser | null>(null);
  const [user, setUser] = useState<User | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(getAuth(), async (user) => {
      if (user) {
        try {
          const res = await getDoc(doc(getFirestore(), "users", user.uid));
          setUser(res.data() as User);
        } catch (error) {
          console.log(error);
        }
      } else {
        setFbUser(null);
      }
    });

    return () => unsubscribe();
  }, []);

  return {
    fbUser: fbUser,
    user: user,
  };
};

export const useUserUID = () => {
  const data = getAuth().currentUser?.uid;
  return data;
};

export const useUser = () => {
  const uid = useUserUID();
  return useFirebaseDocCRUD<User>(`users/${uid}`, uid !== undefined);
};

export const useAnotherUser = (uid: string) => {
  return useFirebaseDocCRUD<User>(`users/${uid}`, uid !== undefined);
};
