export type User = {
  uid: string;
  email: string;
  name: string;
  isSeller?: boolean;
  seller?: {
    name: string;
    phone: string;
    city: string;
    businessProof: string;
    address: string;
  };
};
