import { useQuery, useQueryClient } from "react-query";
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  getFirestore,
  setDoc,
  updateDoc,
  documentId,
} from "firebase/firestore";
import { useState } from "react";
import { FirebaseLoadingType, FirebaseMapType } from "./providers-hook";
import { v4 } from "uuid";

export const useFireCollectionCRUD = <T extends FirebaseMapType<any>>(
  path: string,
  enabled: boolean
) => {
  const [error, setError] = useState<string | undefined>(undefined);
  const [loading, setLoading] = useState<FirebaseLoadingType>(undefined);

  const colRef = collection(getFirestore(), path);
  const qc = useQueryClient();

  const _fetchAll = async (): Promise<T[]> => {
    const data = await getDocs(colRef);
    return data.docs.map((doc) => {
      return {
        ...doc.data(),
        id: doc.id,
      } as T;
    });
  };
  const q = useQuery(
    [path],
    () => {
      return _fetchAll();
    },
    {
      enabled: enabled,
    }
  );

  //
  const add = async (item: T): Promise<string | undefined> => {
    try {
      setLoading("addLoading");
      setError(undefined);
      const id = v4();
      const res = await setDoc(doc(colRef, id), {
        ...item,
        id: id,
      });
      setLoading(undefined);
      qc.invalidateQueries([path]);
      return id;
    } catch (error) {
      setError("Error Adding Data");
      setLoading(undefined);
    }
  };

  const update = async (docId: string, item: T) => {
    const docRef = doc(colRef, docId);
    try {
      setLoading("updateLoading");
      setError(undefined);
      await updateDoc(docRef, {
        ...item,
        id: docId,
      });
      qc.invalidateQueries([path]);
    } catch (error) {
      setError("Error Updating Data");
    }
    setLoading(undefined);
  };

  const remove = async (docId: string) => {
    const docRef = doc(colRef, docId);
    try {
      setLoading("deleteLoading");
      setError(undefined);
      await deleteDoc(docRef);
      qc.invalidateQueries([path]);
    } catch (error) {
      setError("Error Deleting Data");
    }
    setLoading(undefined);
  };

  return {
    data: q.data,
    error: q.error?.toString() || error,
    loading: q.isLoading ? "loadLoading" : loading,
    loadingAny: loading !== undefined || q.isLoading,
    add,
    update,
    remove,
  };
};

export const useFirebaseDocCRUD = <T extends FirebaseMapType<any>>(
  path: string,
  enabled: boolean
) => {
  const [error, setError] = useState<string | undefined>(undefined);
  const [loading, setLoading] = useState<FirebaseLoadingType>(undefined);

  const docRef = doc(getFirestore(), path);
  const qc = useQueryClient();

  const _fetch = async (): Promise<T | undefined> => {
    const data = await getDoc(docRef);
    if (data.exists()) {
      return {
        ...data.data(),
        id: data.id,
      } as T;
    }
    return undefined;
  };
  const q = useQuery(
    [path],
    () => {
      return _fetch();
    },
    {
      enabled: enabled,
    }
  );

  //
  const set = async (item: T): Promise<string | undefined> => {
    try {
      setLoading("addLoading");
      setError(undefined);
      const res = await setDoc(docRef, {
        ...item,
      });
      setLoading(undefined);
      qc.invalidateQueries([path]);
      return "";
    } catch (error) {
      setError("Error Adding Data");
      setLoading(undefined);
    }
  };

  const update = async (item: T) => {
    try {
      setLoading("updateLoading");
      setError(undefined);
      await updateDoc(docRef, {
        ...item,
      });
      qc.invalidateQueries([path]);
    } catch (error) {
      setError("Error Updating Data");
    }
    setLoading(undefined);
  };

  const remove = async () => {
    try {
      setLoading("deleteLoading");
      setError(undefined);
      await deleteDoc(docRef);
      qc.invalidateQueries([path]);
    } catch (error) {
      setError("Error Deleting Data");
    }
    setLoading(undefined);
  };

  return {
    data: q.data,
    error: q.error?.toString() || error,
    loading: q.isLoading ? "loadLoading" : loading,
    loadingAny: loading !== undefined || q.isLoading,
    set,
    update,
    remove,
  };
};
