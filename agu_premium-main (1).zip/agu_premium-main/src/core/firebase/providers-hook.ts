import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  getFirestore,
  updateDoc,
} from "firebase/firestore";
import { useEffect, useRef, useState } from "react";
import { MapType } from "../../utils/misc";

export type FirebaseLoadingType =
  | "loading"
  | "loadLoading"
  | "addLoading"
  | "updateLoading"
  | "deleteLoading"
  | undefined;

export type FirebaseMapType<T> = MapType<T> & {
  id?: string;
};
