import { initializeApp, FirebaseApp } from "firebase/app";
const firebaseConfig = {
  apiKey: "AIzaSyCaOh5wH9Wt30hUqjClBCUu_qBVRhdBUbc",
  authDomain: "agu3377-e2246.firebaseapp.com",
  projectId: "agu3377-e2246",
  storageBucket: "agu3377-e2246.appspot.com",
  messagingSenderId: "857516539388",
  appId: "1:857516539388:web:3235b53418ce75008a8679",
  measurementId: "G-9G9C2JZ4GJ",
};

export class Firebase {
  //Instance
  private static instance: Firebase;
  public static getInstance(): Firebase {
    if (!Firebase.instance) {
      Firebase.instance = new Firebase();
    }
    return Firebase.instance;
  }

  //

  public app: FirebaseApp | undefined;
  public initilize() {
    this.app = initializeApp(firebaseConfig);
  }
}
