import React from "react";
import { appLang } from "../app-lang";

export const AGUDevTools = () => {
  return (
    <div className="p-1">
      <button
        onClick={() => {
          appLang.toggleLang();
        }}
      >
        Toggle Language
      </button>
    </div>
  );
};
