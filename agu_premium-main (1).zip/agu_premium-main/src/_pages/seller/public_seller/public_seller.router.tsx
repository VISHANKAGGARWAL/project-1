import { Outlet, Route, Routes } from "react-router-dom";
import { SellerHeader } from "./compo/header";
import { PublicSellerHome } from "./public_seller";
import { useAnotherUser } from "../../../core/auth/auth-hooks";
import { ProductDetailsPage } from "../../product/product-details";
import { CartPage } from "../../cart/cart-page";
import { ThankYouPage } from "../../cart/thank-you";

export const PublicSellerRouter = (props: { sellerId: string }) => {
  const sellerUser = useAnotherUser(props.sellerId);

  return (
    <Routes>
      <Route
        path="*"
        element={
          <>
            <SellerHeader sellerUser={sellerUser.data} />
            <Outlet />
          </>
        }
      >
        <Route index element={<PublicSellerHome sellerId={props.sellerId} />} />
        <Route path="product/:id" element={<ProductDetailsPage />} />
        <Route path="cart/*" element={<CartPage />} />
        <Route
          path="thankyou"
          element={<ThankYouPage sellerData={sellerUser.data} />}
        />
      </Route>
    </Routes>
  );
};
