import { Banner } from "../../../_components/banner/banner";
import { ProductCard } from "../../../_components/product-card";
import { useAnotherUser } from "../../../core/auth/auth-hooks";
import { CartAtomProvider, cartAtom } from "../../../providers/cart";
import { useSellerProducts } from "../seller/providers/products/product-data";
import { SellerHeader } from "./compo/header";

export const PublicSellerHome = (props: { sellerId: string }) => {
  const products = useSellerProducts(props.sellerId);

  return (
    <CartAtomProvider value={cartAtom}>
      {/*  */}
      <div className="flex flex-col w-full">
        {(() => {
          if (products.loading || products.data?.length === 0) {
            return <div>loading...</div>;
          }

          return (
            <>
              <Banner product={products.data![0]} />
            </>
          );
        })()}

        {(() => {
          if (products.loading) {
            return <div>loading...</div>;
          }

          return (
            <>
              <div className="w-full flex justify-center pt-10 pb-52 px-4">
                <div
                  className="max-w-7xl w-full grid 
               gap-2
               grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5
          "
                >
                  {products.data?.map((p, index) => {
                    return (
                      <ProductCard
                        key={index}
                        product={{
                          ...p,
                          seller: {
                            id: props.sellerId,
                          },
                        }}
                      />
                    );
                  })}
                </div>
              </div>
            </>
          );
        })()}
      </div>
    </CartAtomProvider>
  );
};
