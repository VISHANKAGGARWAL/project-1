import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../../../../core/auth/auth-hooks";
import {
  getAppColors,
  IconButton,
  SelectBase,
  useRelicTheme,
} from "../../../../relic-ui";
import { useAppLang } from "../../../../core/app-lang";
import { Logo } from "../../../../_widgets/logo";
import { CartHeaderIcon } from "../../../../_components/common/cart-icon";
import { CommonIcons } from "../../../../_components/common/icons";
import { UserCard } from "../../../../_components/common/user-card";
import { LanguageSelector } from "../../../../_components/common/language-selector";
import { User } from "../../../../core/auth/auth.types";

export const SellerHeader = (props: { sellerUser?: User }) => {
  const { user } = useAuth();

  useRelicTheme();
  const t = useAppLang();

  const menuItems = [
    {
      label: t("Categories"),
      link: "/",
    },
  ];

  return (
    <div className="border-b border-surfaceVariant h-[80px] flex items-center justify-center px-8 ">
      <div className="flex items-center justify-between max-w-7xl w-full">
        {/* Left */}

        <div className="flex items-center gap-[60px]">
          <Link to={`/${props.sellerUser?.uid}`}>
            <h1 className="text-3xl italic font-bold">
              {props.sellerUser?.seller?.name}
            </h1>
          </Link>

          {/* Menu */}

          <div className=" items-center hidden md:flex">
            {menuItems.map((item, index) => {
              return (
                <Link key={index} to={item.link}>
                  <div className="opacity-70 hover:opacity-100 px-4 py-2 transition-all hover:italic hover:scale-105">
                    {item.label}
                  </div>
                </Link>
              );
            })}
          </div>
        </div>

        {/* Right */}

        <div className="flex items-center gap-5">
          <CartHeaderIcon />

          <IconButton
            rounded="50%"
            px={12}
            py={12}
            bgColor={getAppColors().primary.alpha(0.2).css()}
          >
            <CommonIcons.OrdersBox size={18} />
          </IconButton>

          <div className="hidden md:block">
            <UserCard />
          </div>

          <LanguageSelector />
        </div>
      </div>
    </div>
  );
};
