import React from "react";
import { Navigate } from "react-router-dom";

import { HomeCharts } from "./home-charts";
import { Sidebar } from "../../../../../_components/components/misc/sidebar";
import {
  RelicRoutes,
  RouteWithOutlet,
} from "../../../../../_components/components/routes";

export const HomeHome = () => {
  return (
    <div className="h-full">
      <Sidebar
        items={[
          {
            label: "Dashboard",
            path: "",
            alwaysActive: true,
          },
        ]}
      >
        <RelicRoutes
          routes={{
            "": {
              default: RouteWithOutlet(<HomeCharts />),
            },
          }}
        />
      </Sidebar>
    </div>
  );
};
