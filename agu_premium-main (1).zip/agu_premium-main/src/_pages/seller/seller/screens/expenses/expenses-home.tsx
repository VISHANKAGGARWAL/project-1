import React from "react";
import { Navigate } from "react-router-dom";

import { ExpensesAdd } from "./view/expenses-add";
import { ExpensesView } from "./view/expenses-view";
import {
  RelicRoutes,
  RouteWithOutlet,
  RouteWithPopup,
} from "../../../../../_components/components/routes";
import { Sidebar } from "../../../../../_components/components/misc/sidebar";

export const ExpensesHome = () => {
  return (
    <div className="h-full">
      <Sidebar
        items={[
          {
            label: "View Expenses",
            path: "view",
          },
        ]}
      >
        <RelicRoutes
          routes={{
            "": <Navigate to="view" />,
            view: {
              default: RouteWithOutlet(<ExpensesView />),
              add: RouteWithPopup(<ExpensesAdd />),
              "edit/:id": RouteWithPopup(<ExpensesAdd />),
            },
          }}
        />
      </Sidebar>
    </div>
  );
};
