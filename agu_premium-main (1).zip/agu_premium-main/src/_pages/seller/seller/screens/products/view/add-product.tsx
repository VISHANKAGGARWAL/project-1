import React, { ChangeEvent, useRef } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Select from "react-select";
import { useCategories } from "../../../providers/products/category-data";
import {
  InventoryProduct,
  useProducts,
} from "../../../providers/products/product-data";
import { Unit } from "../../../providers/units/unit";
import {
  Form,
  useRelicForm,
} from "../../../../../../_components/components/base/form";
import { Container } from "../../../../../../_components/components/misc/container";
import {
  ButtonBase,
  InputBase,
  SelectBase,
  TextArea,
} from "../../../../../../relic-ui";
import { CommonIcons } from "../../../../../../_components/common/icons";
import { ref, getStorage, uploadBytes, getDownloadURL } from "firebase/storage";

export const AddProduct = () => {
  const { id } = useParams();

  const products = useProducts();
  const navigate = useNavigate();

  const categories = useCategories();

  const product = products.data?.find((p) => p.id === id);

  const formObj = useRelicForm({
    name: product?.name || "",
    description: product?.description || "",
    category: categories.data
      ? {
          value:
            categories.data?.find((c) => c.name === product?.category)?.id ??
            product?.category,
          label: product?.category,
        }
      : "",
    buyingPrice: product?.buyingPrice || 0,
    sellingPrice: product?.sellingPrice || 0,
    quantity: product?.quantity || 1,
    stock: product?.stock || 0,
    taxPerc: product?.taxPerc || 0,
    unit: {
      value: Unit.getUnit(product?.unit?.name ?? "").symbol,
      label: Unit.getUnit(product?.unit?.name ?? "").name,
    },
  });

  const [images, setImages] = React.useState<(File | string)[]>(
    product?.images ?? []
  );
  const [isUploading, setIsUploading] = React.useState(false);

  const [bigDescription, setBigDescription] = React.useState(
    product?.bigDescription ?? ""
  );

  return (
    <div
      className="bg-surfaceVariant 
    text-onSurfaceVariant rounded-lg p-2 
    w-[300px]
    overflow-auto max-h-screen  flex flex-col"
    >
      <Form
        className="w-full"
        formHookObj={formObj}
        onSubmit={async (data) => {
          setIsUploading(true);
          try {
            if (id) {
              const imagesUrls: string[] = [];
              const storage = getStorage();
              const storageRef = ref(storage, "images");

              for (const image of images) {
                const isFile = image instanceof File;
                if (!isFile) {
                  imagesUrls.push(image);
                  continue;
                }

                const uid = Math.random().toString(36).substring(2);

                const imageRef = ref(storageRef, `${image.name + uid}.jpg`);
                await uploadBytes(imageRef, image);
                imagesUrls.push(await getDownloadURL(imageRef));
              }

              // edit
              const p: InventoryProduct = {
                ...product!,
                ...data,
                category:
                  categories.data?.find((c) => c.id === data.category)?.name ??
                  "",
                unit: Unit.getUnit(data.unit as unknown as string),
                images: imagesUrls,
                bigDescription,
              };
              await products.update(id, p);
            } else {
              // upload images to firebase storage
              const imagesUrls: string[] = [];
              const storage = getStorage();
              const storageRef = ref(storage, "images");

              for (const image of images) {
                const isFile = image instanceof File;
                if (!isFile) {
                  imagesUrls.push(image);
                  continue;
                }

                const uid = Math.random().toString(36).substring(2);

                const imageRef = ref(storageRef, `${image.name + uid}.jpg`);
                await uploadBytes(imageRef, image);
                imagesUrls.push(await getDownloadURL(imageRef));
              }

              // new
              const p: InventoryProduct = {
                ...data,
                category:
                  categories.data?.find((c) => c.id === data.category)?.name ??
                  "",
                unit: Unit.getUnit(data.unit as unknown as string),
                images: imagesUrls,
                bigDescription,
              };
              await products.add(p);
            }
            navigate(-1);
          } finally {
            setIsUploading(false);
          }
        }}
      >
        <Container>
          <h1 className="px-2 py-2 ">Add Product</h1>
          {/*  */}
          <InputBase
            ref={formObj.fieldRefs.name}
            label="Name"
            placeholder="eg. Toaster"
            validator={(v) => {
              if (!v) return "required";
            }}
          />
          <InputBase
            ref={formObj.fieldRefs.description}
            label="Description"
            validator={(v) => {
              if (!v) return "required";
            }}
          />

          <textarea
            placeholder="Detailed Description"
            value={bigDescription}
            onChange={(e) => setBigDescription(e.target.value)}
            className="w-full h-24 p-2 rounded-lg bg-black/20 my-2"
            rows={8}
          />

          <SelectBase
            ref={formObj.fieldRefs.category}
            label="Category"
            options={
              categories.data?.map((c) => ({
                value: c.id!,
                label: c.name,
              })) || []
            }
            validator={(v) => {
              if (!v) return "required";
            }}
            placeholder="Select Category"
          />

          <div className="flex space-y-1 flex-col p-2 rounded-lg bg-black/20 my-2">
            <InputBase
              ref={formObj.fieldRefs.buyingPrice}
              label="Buying Price"
              validator={(v) => {
                if (!v) return "required";
                if (Number.isNaN(Number(v))) return "Invalid Value";
              }}
            />
            <div className="flex space-x-2">
              <InputBase
                ref={formObj.fieldRefs.sellingPrice}
                label="Selling Price"
                validator={(v) => {
                  if (!v) return "required";
                  if (Number.isNaN(Number(v))) return "Invalid Value";
                }}
              />
              <InputBase
                ref={formObj.fieldRefs.quantity}
                label="Per Unit"
                validator={(v) => {
                  if (!v) return "required";
                  if (Number.isNaN(Number(v))) return "Invalid Value";
                }}
              />
            </div>

            {/*  */}

            <SelectBase
              ref={formObj.fieldRefs.unit}
              label="Unit"
              options={Unit.units.map((c) => ({
                value: c.symbol,
                label: c.name,
              }))}
              validator={(v) => {
                if (!v) return "required";
              }}
              placeholder="Select Unit"
            />

            {/*  */}
          </div>

          <InputBase
            ref={formObj.fieldRefs.stock}
            label="Stock (Optional)"
            validator={(v) => {
              if (!v) return undefined;
              if (Number.isNaN(Number(v))) return "Invalid Stock";
            }}
          />

          <InputBase
            ref={formObj.fieldRefs.taxPerc}
            label="Tax Percentage"
            validator={(v) => {
              if (!v) return "required";
              if (Number.isNaN(Number(v))) return "Invalid Value";
            }}
          />

          {/* Images */}
          <div className="flex flex-col space-y-2 pt-4">
            <label className="flex flex-col space-y-1">
              <span className="text-sm">Images</span>
            </label>
            <div className="flex gap-2 flex-wrap">
              {images.map((i, index) => {
                const isFile = i instanceof File;

                return (
                  <div
                    className="w-16 h-16 bg-black/20 rounded-lg relative overflow-clip"
                    key={(isFile ? i.name : i) + index.toString()}
                  >
                    <img
                      src={isFile ? URL.createObjectURL(i) : i}
                      className="w-full h-full object-cover rounded-lg "
                    />

                    {/* Delete Button */}
                    <div className="absolute inset-0  bg-black/50 p-2">
                      <button
                        type="button"
                        className=" "
                        onClick={() => {
                          setImages(images.filter((_, i2) => i2 !== index));
                        }}
                      >
                        <CommonIcons.Delete className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}

              {/* Add Button */}
              <div className="w-16 h-16 bg-black/20 rounded-lg flex items-center justify-center">
                <button
                  type="button"
                  onClick={() => {
                    const input = document.createElement("input");
                    input.type = "file";
                    input.multiple = true;
                    input.onchange = (e) => {
                      if (
                        (e as unknown as ChangeEvent<HTMLInputElement>).target
                          ?.files
                      ) {
                        setImages([
                          ...images,
                          ...(e as unknown as ChangeEvent<HTMLInputElement>)
                            .target.files!,
                        ]);
                      }
                    };
                    input.click();
                  }}
                >
                  <CommonIcons.Add className="w-6 h-6" />
                </button>
              </div>
            </div>
          </div>

          <div className="pt-4 w-full">
            <ButtonBase
              loading={
                (products.loadingAny !== false ? true : undefined) ||
                isUploading
              }
              type="submit"
              className="w-full"
              fullWidth
            >
              Save
            </ButtonBase>
          </div>
        </Container>
      </Form>
    </div>
  );
};
