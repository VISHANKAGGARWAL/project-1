import React from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  Category,
  useCategories,
} from "../../../providers/products/category-data";
import {
  Form,
  useRelicForm,
} from "../../../../../../_components/components/base/form";
import { Container } from "../../../../../../_components/components/misc/container";
import { ButtonBase, InputBase } from "../../../../../../relic-ui";

export const AddCategoryForm = () => {
  const { id } = useParams();

  const categories = useCategories();
  const navigate = useNavigate();

  const category = categories.data?.find((p) => p.id === id);

  const formObj = useRelicForm({
    name: category?.name || "",
    description: category?.description || "",
  });

  return (
    <div className="bg-surfaceVariant text-onSurfaceVariant rounded-lg p-2 overflow-auto max-h-screen  flex flex-col">
      <Form
        formHookObj={formObj}
        onSubmit={async (data) => {
          if (id) {
            // this is and edit
            const p: Category = {
              ...category,
              ...data,
            };
            await categories.update(id, p);
          } else {
            // this is a new data
            const p: Category = {
              ...data,
            };
            await categories.add(p);
          }
          navigate(-1);
        }}
      >
        <Container>
          <h1 className="px-2 py-2 ">Add Category</h1>
          {/*  */}
          <InputBase
            ref={formObj.fieldRefs.name}
            label="Category Name"
            placeholder="eg. Electronics"
            validator={(v) => {
              if (!v) return "required";
            }}
          />
          <InputBase
            ref={formObj.fieldRefs.description}
            label="Description"
            validator={(v) => {
              if (!v) return "required";
            }}
          />
          <div className="pt-4 w-full">
            <ButtonBase
              loading={categories.loadingAny !== false ? true : undefined}
              type="submit"
              className="w-full"
            >
              Save
            </ButtonBase>
          </div>
        </Container>
      </Form>
    </div>
  );
};
