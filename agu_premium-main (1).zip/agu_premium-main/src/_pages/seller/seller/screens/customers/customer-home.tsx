import { Navigate } from "react-router-dom";

import { CustomerAdd } from "./view/customer-add";
import { CustomerView } from "./view/customer-view";
import { Sidebar } from "../../../../../_components/components/misc/sidebar";
import {
  RelicRoutes,
  RouteWithOutlet,
  RouteWithPopup,
} from "../../../../../_components/components/routes";

export const CustomerHome = () => {
  return (
    <div className="h-full">
      <Sidebar
        items={[
          {
            label: "View Customers",
            path: "view",
          },
        ]}
      >
        <RelicRoutes
          routes={{
            "": <Navigate to="view" />,
            view: {
              default: RouteWithOutlet(<CustomerView />),
              add: RouteWithPopup(<CustomerAdd />),
              "edit/:id": RouteWithPopup(<CustomerAdd />),
            },
          }}
        />
      </Sidebar>
    </div>
  );
};
