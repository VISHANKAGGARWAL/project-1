import React from "react";
import { useNavigate } from "react-router-dom";
import {
  Customer,
  customersDataHeadings,
  useCustomers,
} from "../../../providers/customers/customer-data";
import { DataWaiter } from "../../../../../../_components/components/base/loader/data-waiter";
import { DataViewer } from "../../../../../../_components/components/_components/data-viewer";
import { QuickPopup } from "../../../../../../_components/components/quick-popup";

export const CustomerView = () => {
  const data = useCustomers();
  const navigate = useNavigate();

  return (
    <DataWaiter loading={data.loading === "loadLoading"} error={data.error}>
      <DataViewer<Customer>
        data={data.data!}
        searchFn={(v, d) =>
          d.filter((p) => p.name.toLowerCase().includes(v.toLowerCase()))
        }
        columnsHeadings={customersDataHeadings}
        excludeColumns={["id"]}
        renderRow={(d) => ({
          ...d,
          transactions:
            d.transactions?.length ?? 0 > 0 ? (
              <QuickPopup
                id={"customer-transaction-view-" + d.id}
                noHide={true}
                popup={
                  <div className="flex p-4 flex-col ">
                    <h1>Trasactions</h1>
                    <div className="flex flex-col-reverse space-y-1 overflow-auto max-h-[300px]">
                      {d.transactions?.map((t) => (
                        <button
                          key={t}
                          onClick={() => {
                            navigate(`/transactions/view/details/${t}`);
                          }}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>
                }
              >
                <button>{d.transactions?.length ?? 0} Transactions</button>
              </QuickPopup>
            ) : (
              <p>{d.transactions?.length ?? 0} Transactions</p>
            ),
        })}
        //
        addButton={{
          text: "Add Customer",
          navigate: "add",
        }}
        //
        actions={{
          edit: (row) => ({ to: `edit/${row.id}` }),
          delete: (row) => {
            data.remove(row.id!);
          },
        }}
      />
    </DataWaiter>
  );
};
