import React from "react";
import { Navigate } from "react-router-dom";
import { SettingsProfile } from "./settings-profile";
import { Sidebar } from "../../../../../_components/components/misc/sidebar";
import {
  RelicRoutes,
  RouteWithOutlet,
} from "../../../../../_components/components/routes";

export const SettingsHome = () => {
  return (
    <div className="h-full">
      <Sidebar
        items={[
          {
            label: "Profile",
            path: "profile",
          },
        ]}
      >
        <RelicRoutes
          routes={{
            "": <Navigate to="profile" />,
            profile: {
              default: RouteWithOutlet(<SettingsProfile />),
              //   add: RouteWithPopup(<TransactionAdd />),
            },
          }}
        />
      </Sidebar>
    </div>
  );
};
