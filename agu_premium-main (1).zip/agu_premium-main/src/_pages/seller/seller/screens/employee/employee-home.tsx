import { Navigate } from "react-router-dom";

import { EmployeeAdd } from "./view/employee-add";
import { EmployeeView } from "./view/employee-view";
import { Sidebar } from "../../../../../_components/components/misc/sidebar";
import {
  RelicRoutes,
  RouteWithOutlet,
  RouteWithPopup,
} from "../../../../../_components/components/routes";

export const EmployeeHome = () => {
  return (
    <div className="h-full">
      <Sidebar
        items={[
          {
            label: "View Employees",
            path: "view",
          },
        ]}
      >
        <RelicRoutes
          routes={{
            "": <Navigate to="view" />,
            view: {
              default: RouteWithOutlet(<EmployeeView />),
              add: RouteWithPopup(<EmployeeAdd />),
              "edit/:id": RouteWithPopup(<EmployeeAdd />),
            },
          }}
        />
      </Sidebar>
    </div>
  );
};
