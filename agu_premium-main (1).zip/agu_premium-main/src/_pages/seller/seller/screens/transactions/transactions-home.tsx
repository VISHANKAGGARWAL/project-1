import { Navigate } from "react-router-dom";
import { TransactionAdd } from "./view/transaction-add";
import { TransactionDetails } from "./view/transaction-detail";
import { TransactionPrint } from "./view/transaction-print";
import { TransactionsView } from "./view/transactions-view";
import {
  RelicRoutes,
  RouteWithOutlet,
  RouteWithPopup,
} from "../../../../../_components/components/routes";
import { Sidebar } from "../../../../../_components/components/misc/sidebar";

export const TrasactionsHome = () => {
  return (
    <div className="h-full">
      <Sidebar
        items={[
          {
            label: "All Transactions",
            path: "view",
          },
        ]}
      >
        <RelicRoutes
          routes={{
            "": <Navigate to="view" />,
            view: {
              default: RouteWithOutlet(<TransactionsView />),
              add: RouteWithPopup(<TransactionAdd />),
              // "edit/:id": RouteWithPopup(<TransactionAdd />),
              "details/:id": RouteWithPopup(<TransactionDetails />),
              "add/add-product": RouteWithPopup(<TransactionAdd />),
            },
          }}
        />
      </Sidebar>
    </div>
  );
};
