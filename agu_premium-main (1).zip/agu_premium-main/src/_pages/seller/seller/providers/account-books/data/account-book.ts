import { atom, useAtom } from "jotai";
import { useUser } from "../../../../../../core/auth/auth-hooks";
import {
  useFireCollectionCRUD,
  useFirebaseDocCRUD,
} from "../../../../../../core/firebase/providers-hook-new";

export interface AccountBook {
  id?: string;
  createdAt: Date;
  name: string;
  invoiceDetails?: {
    orgName: string;
    orgAddress: string;
    orgPhone: string;
    orgEmail: string;
    orgWebsite: string;
    orgProof: string;
  };
}

export const currentAccountBook = atom(undefined as AccountBook | undefined);

export const useCurrentAccountBook = () => {
  const user = useUser();
  const [book, setBook] = useAtom(currentAccountBook);
  return {
    book,
    bookPath: `seller/${user.data?.uid}`,
  };
};

export const useAccountBooks = () => {
  const user = useUser();

  const accountBook = useFirebaseDocCRUD<AccountBook>(
    `seller/${user.data?.uid}`,
    false
  );
  return accountBook;
};
