import { css } from "@emotion/react";
import chroma from "chroma-js";
import { useAtom } from "jotai";
import React, { useEffect, useState } from "react";

import { currentAccountBook, useAccountBooks } from "./data/account-book";
import { useRelicTheme } from "../../../../../relic-ui";
import { DataWaiter } from "../../../../../_components/components/base/loader/data-waiter";
import { useUser } from "../../../../../core/auth/auth-hooks";

export const AccountBookProvider = (props: { children: React.ReactNode }) => {
  const accountBooks = useAccountBooks();
  const [accountBook, setAccountBook] = useAtom(currentAccountBook);

  useEffect(() => {
    setAccountBook(accountBooks.data);
  }, [accountBooks.data]);

  useRelicTheme();

  return (
    <DataWaiter
      loading={accountBooks.loading === "loadLoading"}
      error={accountBooks.error}
    >
      {props.children}
    </DataWaiter>
  );
};
