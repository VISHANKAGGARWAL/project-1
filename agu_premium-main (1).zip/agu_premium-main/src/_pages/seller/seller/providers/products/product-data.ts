import { useAtom } from "jotai";
import { Unit } from "../units/unit";
import { useUser } from "../../../../../core/auth/auth-hooks";
import { useFireCollectionCRUD } from "../../../../../core/firebase/providers-hook-new";
import { useCurrentAccountBook } from "../account-books/data/account-book";
import { useHomeAllProducts } from "../../../../home/prov/all-products";

export interface InventoryProduct {
  id?: string;
  name: string;
  description: string;
  bigDescription: string;
  category: string;
  //
  sellingPrice: number;
  buyingPrice: number;
  //
  quantity: number;
  unit: Unit;
  //
  stock: number;
  //
  taxPerc: number;
  images: string[];
}

export interface InventoryProductWithSeller extends InventoryProduct {
  seller: {
    id: string;
  };
}

export const productsDataHeadings = {
  id: "ID",
  name: "Name",
  description: "Description",
  bigDescription: "Detailed Description",
  category: "Category",
  buyingPrice: "Buying Price",
  sellingPrice: "Selling Price",
  quantity: "Quantity",
  unit: "Unit",
  stock: "Stock",
  taxPerc: "Tax %",
  images: "Images",
};

export const useProducts = () => {
  const user = useUser();
  const book = useCurrentAccountBook();

  const products = useFireCollectionCRUD<InventoryProduct>(
    `${book.bookPath}/products`,
    !!user.data
  );
  return products;
};

export const useSellerProducts = (sellerId: string) => {
  const products = useFireCollectionCRUD<InventoryProduct>(
    `seller/${sellerId}/products`,
    true
  );
  return products;
};

export const useGetProductById = (id: string) => {
  const products = useHomeAllProducts();
  const product = products.data?.find((p) => p.id === id);
  return {
    data: product,
    loading: products.loading,
    error: products.error,
  };
};
