import React from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { useAuth } from "../../core/auth/auth-hooks";
import { BecomeSeller } from "./becomeseller/becomeseller";
import { Home } from "./seller/screens/home";
import { AccountBookProvider } from "./seller/providers/account-books/account-book-provider";

export const SellerRouter = () => {
  const { user } = useAuth();
  const isSeller = user?.isSeller;

  if (!user) {
    return <></>;
  }

  if (isSeller) {
    return (
      <AccountBookProvider>
        <Home />
      </AccountBookProvider>
    );
  }

  // no seller
  return (
    <>
      <Routes>
        <Route index element={<Navigate to="become-a-seller" />} />
        <Route path="become-a-seller" element={<BecomeSeller />} />
      </Routes>
    </>
  );
};
