import {
  addDoc,
  collection,
  doc,
  getFirestore,
  setDoc,
  updateDoc,
} from "firebase/firestore";
import React from "react";
import { useAppLang } from "../../../core/app-lang";
import { useAuth } from "../../../core/auth/auth-hooks";
import {
  ButtonBase,
  Form,
  InputBase,
  useInputController,
} from "../../../relic-ui";

export const BecomeSeller = () => {
  const auth = useAuth();

  const t = useAppLang();

  const nameRef = useInputController();
  const phoneRef = useInputController();
  const addressRef = useInputController();
  const cityRef = useInputController();
  const businessProofRef = useInputController();

  const [isLoading, setIsLoading] = React.useState(false);

  const onSubmit = async () => {
    setIsLoading(true);

    if (
      !nameRef.current?.validate() ||
      !phoneRef.current?.validate() ||
      !addressRef.current?.validate() ||
      !cityRef.current?.validate() ||
      !businessProofRef.current?.validate()
    ) {
      return;
    }

    const name = nameRef.current?.value;
    const phone = phoneRef.current?.value;
    const address = addressRef.current?.value;
    const city = cityRef.current?.value;
    const businessProof = businessProofRef.current?.value;

    try {
      // update user doc in firestore
      await updateDoc(doc(getFirestore(), "users", auth.user?.uid ?? ""), {
        isSeller: true,
        seller: {
          name,
          phone,
          address,
          city,
          businessProof,
        },
      });

      await setDoc(doc(getFirestore(), "seller", auth.user?.uid ?? ""), {
        date: new Date(),
      });

      // refresh page
      window.location.reload();
    } catch (error) {}

    setIsLoading(false);
  };

  return (
    <div className="flex items-center h-full justify-center">
      <div className="w-full max-w-xs flex flex-col gap-1 ">
        <h1 className="text-2xl italic w-full text-center font-bold pb-4">
          {t("Become a Seller")}
        </h1>

        <InputBase
          label={t("Shop Name") ?? ""}
          ref={nameRef}
          placeholder={t("Enter your shop name") ?? ""}
          type="text"
          validator={(value) => {
            if (value.length < 5) {
              return t("Shop name must be atleast 5 characters long");
            }
            return;
          }}
        />

        <InputBase
          label={t("Phone Number") ?? ""}
          ref={phoneRef}
          placeholder={t("Enter your phone number") ?? ""}
          type="text"
          validator={(value) => {
            if (value.length < 10) {
              return t("Phone number must be atleast 10 characters long");
            }
            return;
          }}
        />

        <InputBase
          label={t("Address") ?? ""}
          ref={addressRef}
          placeholder={t("Enter your address") ?? ""}
          type="text"
          validator={(value) => {
            if (!value) {
              return t("Address is required");
            }
            return;
          }}
        />

        <InputBase
          label={t("City") ?? ""}
          ref={cityRef}
          placeholder={t("Enter your city") ?? ""}
          type="text"
          validator={(value) => {
            if (!value) {
              return t("City is required");
            }
            return;
          }}
        />

        <InputBase
          label={t("Business Proof") ?? ""}
          ref={businessProofRef}
          placeholder={t("Enter your business proof") ?? ""}
          type="text"
          validator={(value) => {
            if (!value) {
              return t("Business proof is required");
            }
            return;
          }}
        />

        <ButtonBase
          loading={isLoading}
          onClick={onSubmit}
          fullWidth
          className="mt-4"
        >
          {t("Submit Application")}
        </ButtonBase>
      </div>
    </div>
  );
};
