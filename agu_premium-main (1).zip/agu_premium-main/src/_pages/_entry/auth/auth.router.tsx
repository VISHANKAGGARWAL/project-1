import React from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { LoginPage } from "./login-page";

export const AuthRouter = () => {
  return (
    <>
      <Routes>
        <Route path="" element={<Navigate to="login" />} />
        <Route path="login" element={<LoginPage />} />
        <Route path="register" element={<LoginPage isRegister />} />
      </Routes>
    </>
  );
};
