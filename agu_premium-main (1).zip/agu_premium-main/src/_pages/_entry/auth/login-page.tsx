import {
  ButtonBase,
  Divider,
  getAppColorsString,
  HoverCard,
  InputBase,
  Spacer,
  useInputController,
  useRelicTheme,
} from "./../../../relic-ui";
import chroma from "chroma-js";
import React from "react";
import { FcGoogle } from "react-icons/fc";
import { CommonIcons } from "../../../_components/common/icons";
import { useAppLang } from "../../../core/app-lang";
import { Logo } from "../../../_widgets/logo";
import { Link } from "react-router-dom";
import { ErrorWidget } from "../../../_widgets/error-widgt";
import {
  AuthError,
  createUserWithEmailAndPassword,
  getAuth,
  GoogleAuthProvider,
  signInWithEmailAndPassword,
  signInWithPopup,
} from "firebase/auth";
import { createUserInFirestore } from "../../../core/auth/auth-functions";

export const LoginPage = (props: { isRegister?: boolean }) => {
  useRelicTheme();

  const t = useAppLang();

  const [error, setError] = React.useState<string | null>(null);
  const [loading, setLoading] = React.useState(false);

  const email = useInputController();
  const password = useInputController();
  const name = useInputController();
  const confirmPassword = useInputController();

  const onSignIn = async () => {
    setLoading(true);
    const auth = getAuth();
    try {
      const res = await signInWithEmailAndPassword(
        auth,
        email.current!.value as any,
        password.current!.value as any
      );
    } catch (error) {
      setError((error as AuthError).message);
    }
    setLoading(false);
  };

  const onSignInWithGoogle = async () => {
    setLoading(true);
    const auth = getAuth();
    const provider = new GoogleAuthProvider();
    try {
      const res = await signInWithPopup(auth, provider);
      if (res.user) {
        await createUserInFirestore(res.user.uid, {
          email: res.user.email ?? "",
          name: res.user.displayName ?? "NA",
          uid: res.user.uid,
          isSeller: false,
        });
      }
    } catch (error) {
      setError((error as AuthError).message);
    }
    setLoading(false);
  };
  const onSignUp = async () => {
    // validation
    if (
      !email.current?.value ||
      !password.current?.value ||
      !name.current?.value ||
      !confirmPassword.current?.value
    ) {
      setError(t("Please fill all fields"));
      return;
    }
    if (password.current?.value !== confirmPassword.current?.value) {
      setError(t("Passwords do not match"));
      return;
    }

    //
    setLoading(true);
    const auth = getAuth();
    try {
      const res = await createUserWithEmailAndPassword(
        auth,
        email.current!.value as any,
        password.current!.value as any
      );
      if (res.user) {
        await createUserInFirestore(res.user.uid, {
          email: res.user.email ?? "",
          name: (name.current?.value as string) ?? res.user.displayName ?? "NA",
          uid: res.user.uid,
          isSeller: false,
        });
      }
    } catch (error) {
      setError((error as AuthError).message);
    }
    setLoading(false);
  };

  return (
    <div className="h-full flex w-full justify-evenly items-center">
      {/* Main */}
      <div className="flex w-full  flex-1 flex-col items-center gap-3">
        <div className="flex flex-col gap1 w-full max-w-[300px] transition-all">
          <div className="flex justify-center pb-10 fill-onBackground">
            <Logo />
          </div>
          <h3 className="text-onSurfaceVariant pt-2">{t("Welcome back")}</h3>
          <Spacer h={40} />
          <ButtonBase
            className="flex gap-1"
            bgColor="white"
            fgColor="black"
            fullWidth
            border={`2px solid ${chroma("black").alpha(0.4).css()}`}
            onClick={onSignInWithGoogle}
          >
            <span>
              <FcGoogle size={20} />
            </span>
            <span>{t("Sign in With Google")}</span>
          </ButtonBase>

          <Divider height={80}>{t("OR")}</Divider>

          {!props.isRegister ? (
            <>
              <InputBase
                label={t("Email") ?? "Email"}
                placeholder={t("Email") ?? "Email"}
                type="email"
                bgColor={getAppColorsString().background}
                borderWidth="0 0 2px 0"
                ref={email}
              />
              <Spacer h={8} />
              <InputBase
                label={t("Password") ?? "Password"}
                placeholder={t("Password") ?? "Password"}
                type="password"
                bgColor={getAppColorsString().background}
                borderWidth="0 0 2px 0"
                ref={password}
              />
            </>
          ) : (
            <>
              <InputBase
                label={t("Name") ?? "Name"}
                placeholder={t("Name") ?? "Name"}
                type="text"
                bgColor={getAppColorsString().background}
                borderWidth="0 0 2px 0"
                ref={name}
              />
              <Spacer h={8} />
              <InputBase
                label={t("Email") ?? "Email"}
                placeholder={t("Email") ?? "Email"}
                type="email"
                bgColor={getAppColorsString().background}
                borderWidth="0 0 2px 0"
                ref={email}
              />
              <Spacer h={8} />
              <InputBase
                label={t("Password") ?? "Password"}
                placeholder={t("Password") ?? "Password"}
                type="password"
                bgColor={getAppColorsString().background}
                borderWidth="0 0 2px 0"
                ref={password}
              />
              <Spacer h={8} />
              <InputBase
                label={t("Confirm Password") ?? "Password"}
                placeholder={t("Password") ?? "Password"}
                type="password"
                bgColor={getAppColorsString().background}
                borderWidth="0 0 2px 0"
                ref={confirmPassword}
              />
            </>
          )}

          <Spacer h={15} />

          {error && <div className="text-red-500 text-sm">{error}</div>}

          <Spacer h={40} />
          <ButtonBase
            bgColor={getAppColorsString().inverseSurface}
            fgColor={getAppColorsString().inverseOnSurface}
            fullWidth
            rightIcon={<CommonIcons.ArrowRight size={15} />}
            onClick={props.isRegister ? onSignUp : onSignIn}
            loading={loading}
          >
            {props.isRegister ? t("Sign up") : t("Sign in")}
          </ButtonBase>
          <Spacer h={15} />

          <div>
            {!props.isRegister
              ? t("Don't have an account?")
              : t("Already have an account?")}{" "}
            <Link to={props.isRegister ? "/auth/login" : "/auth/register"}>
              <span className="text-primary  transition-all font-bold hover:italic hover:scale-110">
                {props.isRegister ? t("Sign in") : t("Sign up")}
              </span>
            </Link>
          </div>
        </div>
      </div>

      {/* Image */}
      <div className="flex-1 h-full">
        <img
          src="/world_img.webp"
          alt="World"
          loading="lazy"
          className="w-full h-full object-cover"
        />
      </div>
    </div>
  );
};
