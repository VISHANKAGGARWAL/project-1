import React from "react";
import { createBrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { AuthProvider } from "../../core/auth/auth-provider";
import { HomePage } from "../home/home";
import { SellerRouter } from "../seller/seller.router";
import { AuthRouter } from "./auth/auth.router";
import { useGetAllSellers } from "../../providers/seller-data";
import { PublicSellerHome } from "../seller/public_seller/public_seller";
import { cartAtom, CartAtomProvider } from "../../providers/cart";
import { HomeRouter } from "../home/home.router";
import { PublicSellerRouter } from "../seller/public_seller/public_seller.router";
import { CartPage } from "../cart/cart-page";
import { Brands } from "../menu/brands";

export const EntryPage = () => {
  const sellers = useGetAllSellers();

  return (
    <>
      <CartAtomProvider value={cartAtom}>
        <AuthProvider
          nonAuth={
            <Routes>
              <Route path="" element={<Navigate to="home" />} />
              <Route path="auth/*" element={<AuthRouter />} />
              <Route path="home/*" element={<HomeRouter />} />
              <Route path={"brands"} element={<Brands />} />
            </Routes>
          }
        >
          <Routes>
            <Route path="" element={<Navigate to="home" />} />
            <Route path="home/*" element={<HomeRouter />} />
            <Route path="seller/*" element={<SellerRouter />} />
            <Route path={"brands"} element={<Brands />} />

            {sellers.data?.map((seller) => {
              return (
                <Route
                  key={seller.id}
                  path={seller.id + "/*"}
                  element={<PublicSellerRouter sellerId={seller.id} />}
                />
              );
            })}
          </Routes>
        </AuthProvider>
      </CartAtomProvider>
    </>
  );
};
