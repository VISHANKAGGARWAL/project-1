import React from "react";
import { useRouteError } from "react-router-dom";

export const ErrorPage = () => {
  const error = useRouteError() as Error;

  return (
    <div className="h-full flex flex-col items-center justify-center">
      <div className="flex flex-col items-center">
        <h1 className="text-xl">Error</h1>
        <p>{error.message ?? "Unknown Cause"}</p>
      </div>
    </div>
  );
};
