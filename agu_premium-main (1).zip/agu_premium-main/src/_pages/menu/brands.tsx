import React, { useEffect } from "react";
import { Logo } from "../../_widgets/logo";
import { User } from "../../core/auth/auth.types";
import { useGetAllSellers } from "../../providers/seller-data";
import { doc, getDoc, getFirestore } from "firebase/firestore";
import { getAppColors } from "../../relic-ui";
import { CommonIcons } from "../../_components/common/icons";

export const Brands = () => {
  const sellers = useGetAllSellers();

  const [sellersData, setSellersData] = React.useState<User[]>([]);

  useEffect(() => {
    (async () => {
      if (!sellers.data) {
        return;
      }

      const res = [] as User[];

      for (const seller of sellers.data) {
        const docRef = doc(getFirestore(), "users", seller.id);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          res.push(docSnap.data() as User);
        }
      }

      setSellersData(res);
    })();
  }, [sellers.data]);

  if (!sellers.data) {
    return <div>Loading...</div>;
  }

  return (
    <>
      <div className="h-full w-full max-w-7xl flex flex-col  items-center mx-auto pt-10">
        <Logo width={800} />

        {/*  */}

        <div className="pt-20 flex flex-col gap-4">
          {sellersData.map((seller) => {
            return (
              <div
                key={seller.uid}
                onClick={() => {
                  window.location.href = "/" + seller.uid;
                }}
                style={
                  {
                    //   backgroundColor: getAppColors().primary.alpha(0.4).css(),
                  }
                }
                className="text-3xl italic font-bold bg-tertiary text-onTertiary rounded-lg px-6 py-4 flex items-center gap-4 cursor-pointer hover:opacity-50 transition-all"
              >
                <span>
                  <CommonIcons.Heart />
                </span>
                <span>{seller.seller?.name}</span>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
};
