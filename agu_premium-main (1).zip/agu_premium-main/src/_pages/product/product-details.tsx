import { useNavigate, useParams } from "react-router-dom";
import { useGetProductById } from "../seller/seller/providers/products/product-data";
import { DataWaiter } from "../../_components/components/base/loader/data-waiter";
import { useCartAtom } from "../../providers/cart";
import { useAtom } from "jotai";
import { noProductImageGIF } from "../../_components/product-card";
import { ButtonBase, IconButton, getAppColors } from "../../relic-ui";
import { CommonIcons } from "../../_components/common/icons";
import { formatMoney } from "../../utils/misc";
import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";

export const ProductDetailsPage = () => {
  const { id } = useParams();

  const productData = useGetProductById(id ?? "m");
  const cartAtom = useCartAtom();
  const [cart, setCart] = useAtom(cartAtom);
  const navigate = useNavigate();

  const itemAlreadyInCart = cart.items.find((item) => {
    return item.id === productData?.data?.id;
  });

  const product = productData?.data;

  return (
    <>
      <DataWaiter loading={productData.loading ? true : false}>
        {/*  */}

        {(() => {
          if (!product) {
            return <></>;
          }

          return (
            <>
              <div className="flex flex-col w-full max-w-7xl mx-auto pt-10">
                {/*  */}
                <div className="flex w-full gap-6">
                  {/* Left */}
                  <div className="flex flex-col w-full select-none">
                    <Carousel
                      infiniteLoop
                      interval={5000}
                      emulateTouch
                      swipeable
                    >
                      {product!.images?.map((image, index) => {
                        return (
                          <img
                            key={index}
                            src={image}
                            alt=""
                            width={"100%"}
                            height={"100%"}
                            className="object-cover w-full h-full rounded-xl"
                          />
                        );
                      })}
                    </Carousel>
                  </div>

                  {/* Right */}

                  <div className="flex flex-col w-full">
                    <div className="p-4 flex flex-col gap-1">
                      <h4
                        className="font-bold pb-2
                        text-5xl
                      "
                      >
                        {product?.name}
                      </h4>

                      <h4
                        className="font-semibold italic py-4
                        text-xl
                      "
                      >
                        {product?.description}
                      </h4>

                      {/*  */}

                      {/* <div className="flex gap-2 items-center"></div> */}

                      {/*  */}

                      <div className="flex gap-3 pt-4 items-baseline">
                        <div className="text-5xl italic text-primary font-semibold">
                          {formatMoney(product!.sellingPrice)}
                        </div>
                        <div className="line-through italic opacity-50 text-xl font-semibold">
                          {formatMoney(
                            product!.sellingPrice + product!.sellingPrice * 0.12
                          )}
                        </div>
                        <div className="italic text-tertiary text-sm">
                          (12% off)
                        </div>
                      </div>

                      <div className="flex pt-6 ">
                        <ButtonBase
                          fullWidth
                          onClick={() => {
                            if (itemAlreadyInCart) {
                              navigate("../../cart");

                              return;
                            }

                            setCart((prev) => {
                              return {
                                ...prev,
                                items: [...prev.items, product!],
                              };
                            });
                          }}
                          leftIcon={<CommonIcons.ShoppingCart size={30} />}
                        >
                          <div className="h-[50px] flex flex-col justify-center italic font-bold text-2xl">
                            {itemAlreadyInCart ? "Go to Cart!" : "Add to cart"}
                          </div>
                        </ButtonBase>
                      </div>

                      {/*  */}

                      <div
                        className="  py-8
                        text-base
                      "
                      >
                        {product?.bigDescription}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </>
          );
        })()}
      </DataWaiter>
    </>
  );
};
