import { collection, getDocs, getFirestore } from "firebase/firestore";
import { useFireCollectionCRUD } from "../../../core/firebase/providers-hook-new";
import { useGetAllSellers } from "../../../providers/seller-data";
import {
  InventoryProduct,
  InventoryProductWithSeller,
} from "../../seller/seller/providers/products/product-data";
import { useState } from "react";
import { useQuery } from "react-query";

export const useHomeAllProducts = () => {
  const sellers = useGetAllSellers();

  const getAllSellersProducts = async () => {
    const allProducts: InventoryProductWithSeller[] = [];
    for (const seller of sellers.data!) {
      const products = await getDocs(
        collection(getFirestore(), `seller/${seller.id}/products`)
      );
      products.forEach((product) => {
        allProducts.push({
          ...product.data(),
          seller: {
            id: seller.id,
          },
        } as InventoryProductWithSeller);
      });
    }
    return allProducts;
  };

  const q = useQuery(
    ["allHomeProducts"],
    () => {
      return getAllSellersProducts();
    },
    {
      enabled: sellers.data !== undefined,
    }
  );

  return {
    data: q.data,
    loading: q.isLoading || sellers.loading,
    error: q.error,
  };
};
