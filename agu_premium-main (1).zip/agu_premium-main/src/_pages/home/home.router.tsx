import { Outlet, Route, Routes } from "react-router-dom";
import { HomePage } from "./home";
import { Header } from "../../_components/common/header";
import { ProductDetailsPage } from "../product/product-details";
import { CartPage } from "../cart/cart-page";
import { ThankYouPage } from "../cart/thank-you";

export function HomeRouter() {
  return (
    <Routes>
      <Route
        path="*"
        element={
          <>
            <Header />
            <Outlet />
          </>
        }
      >
        <Route index element={<HomePage />} />
        <Route path="product/:id" element={<ProductDetailsPage />} />
        <Route path="cart/*" element={<CartPage />} />
        <Route path="thankyou" element={<ThankYouPage />} />
      </Route>
    </Routes>
  );
}
