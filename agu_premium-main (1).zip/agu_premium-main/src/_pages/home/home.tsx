import React from "react";
import { Banner } from "../../_components/banner/banner";
import { Header } from "../../_components/common/header";
import { ProductCard } from "../../_components/product-card";
import { useHomeAllProducts } from "./prov/all-products";
import { useBannerProduct } from "../../providers/main-data";

export const HomePage = () => {
  const bannerProduct = useBannerProduct();
  const products = useHomeAllProducts();

  return (
    <div className="flex flex-col w-full">
      {(() => {
        if (bannerProduct.loading) {
          return <div>loading...</div>;
        }

        return (
          <>
            <Banner product={bannerProduct.data} />
          </>
        );
      })()}

      {(() => {
        if (products.loading) {
          return <div>loading...</div>;
        }

        return (
          <>
            <div className="w-full flex justify-center pt-10 pb-52 px-4">
              <div
                className="max-w-7xl w-full grid 
             gap-2
             grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5
        "
              >
                {products.data?.map((p, index) => {
                  return <ProductCard key={index} product={p} />;
                })}
              </div>
            </div>
          </>
        );
      })()}
    </div>
  );
};
