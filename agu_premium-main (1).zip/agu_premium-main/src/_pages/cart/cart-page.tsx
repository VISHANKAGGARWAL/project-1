import { useAtom } from "jotai";
import { useCartAtom } from "../../providers/cart";
import { useNavigate } from "react-router-dom";
import { ProductCartCard } from "../../_components/product-cart-card";
import { formatMoney } from "../../utils/misc";
import { ButtonBase } from "../../relic-ui";
import { CommonIcons } from "../../_components/common/icons";
import { InventoryProductWithSeller } from "../seller/seller/providers/products/product-data";
import {
  Transaction,
  TransactionProduct,
} from "./../seller/seller/providers/transactions/transaction-data";
import { v4 } from "uuid";
import { useUser, useUserUID } from "../../core/auth/auth-hooks";
import React from "react";
import {
  collection,
  doc,
  getDoc,
  getFirestore,
  setDoc,
} from "firebase/firestore";

export const CartPage = () => {
  const userID = useUserUID();
  const user = useUser();

  const cartAtom = useCartAtom();
  const [cart, setCart] = useAtom(cartAtom);
  const navigate = useNavigate();

  const [loading, setLoading] = React.useState(false);

  const cartTotal = cart.items.reduce((acc, item) => {
    return acc + item.sellingPrice;
  }, 0);

  const onBuyNow = async () => {
    if (!userID) {
      navigate("/auth/login");
      return;
    }

    setLoading(true);
    try {
      // group items by seller
      const groupedItems = cart.items.reduce((acc, item) => {
        if (!acc[item.seller.id]) {
          acc[item.seller.id] = [];
        }

        acc[item.seller.id].push(item);

        return acc;
      }, {} as { [key: string]: InventoryProductWithSeller[] });

      const transactions = {} as { [key: string]: Transaction };

      for (const sellerId in groupedItems) {
        const items = groupedItems[sellerId];

        const profit = items.reduce((acc, item) => {
          return acc + (item.sellingPrice - item.buyingPrice);
        }, 0);

        const transaction: Transaction = {
          id: v4(),
          customerId: userID,
          customerName: user?.data?.name ?? "",
          customerPhone: user?.data?.email ?? "",
          date: new Date(),
          discount: 0,
          discountType: "amount",
          change: 0,
          grandTotal: cartTotal,
          netTotal: cartTotal,
          paid: true,
          payment: cartTotal,
          products: items.map((item) => {
            return {
              category: item.category,
              productId: item.id,
              description: item.description,
              name: item.name,
              netPrice: item.sellingPrice,
              price: item.sellingPrice,
              quantityPerUnit: item.quantity,
              quantityPurchased: item.quantity,
              taxPerc: 0,
              totalPrice: item.sellingPrice * item.quantity,
              unit: item.unit,
            } as TransactionProduct;
          }),
          profit: profit,
          tax: 0,
          total: cartTotal,
        };

        transactions[sellerId] = transaction;
      }

      // upload

      for (const sellerId in transactions) {
        const transaction = transactions[sellerId];
        const colRef = collection(
          getFirestore(),
          `seller/${sellerId}/transactions`
        );
        await setDoc(doc(colRef, transaction.id), transaction);

        const customerDocRef = doc(
          getFirestore(),
          `seller/${sellerId}/customers/${userID}`
        );
        const customer = await getDoc(customerDocRef);
        if (customer.exists()) {
          await setDoc(customerDocRef, {
            ...customer.data(),
            transactions: [
              ...(customer.data()?.transactions ?? []),
              transaction.id,
            ],
          });
        } else {
          await setDoc(customerDocRef, {
            id: userID,
            name: user?.data?.name ?? "",
            phone: user?.data?.email ?? "",
            transactions: [transaction.id],
          });
        }
      }

      setCart({
        items: [],
      });

      navigate("../thankyou");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-7xl flex flex-col mx-auto pt-4">
      {/*  */}

      <div className="flex flex-col gap-4">
        {cart.items.map((item, index) => {
          return <ProductCartCard product={item} key={index} />;
        })}
      </div>

      {/*  Total */}

      <div className="flex flex-col">
        <div className="flex justify-between items-center pt-10">
          <div className="text-xl ">Total</div>
          <div className="text-3xl text-primary font-bold italic">
            {formatMoney(cartTotal)}
          </div>
        </div>

        {/*  */}

        <div className="flex justify-between items-center pt-8">
          <div className="text-xl "></div>
          <div className="text-3xl text-primary font-bold italic">
            <ButtonBase
              onClick={onBuyNow}
              leftIcon={<CommonIcons.ShoppingCart size={26} />}
              loading={loading}
              disabled={loading}
            >
              Buy Now
            </ButtonBase>
          </div>
        </div>
      </div>
    </div>
  );
};
