import { useNavigate } from "react-router-dom";
import { Logo } from "../../_widgets/logo";
import { User } from "../../core/auth/auth.types";
import { ButtonBase } from "../../relic-ui";

export const ThankYouPage = (props: { sellerData?: User }) => {
  const navigate = useNavigate();

  return (
    <>
      <div className="h-full w-full flex flex-col justify-center items-center">
        {(() => {
          if (!props.sellerData) {
            return <Logo width={500} />;
          } else {
            return (
              <div className="font-bold italic text-7xl ">
                {props.sellerData.seller?.name}
              </div>
            );
          }
        })()}

        <div className="font-bold italic text-4xl py-4 pt-16">
          Thank you for your purchase
        </div>

        <div className="text-2xl italic pt-8 pb-10">
          The seller will contact you soon
        </div>

        <ButtonBase
          onClick={() => {
            if (!props.sellerData) {
              navigate("/home");
            } else {
              navigate("/" + props.sellerData?.uid);
            }
          }}
        >
          Go to Home
        </ButtonBase>
      </div>
    </>
  );
};
