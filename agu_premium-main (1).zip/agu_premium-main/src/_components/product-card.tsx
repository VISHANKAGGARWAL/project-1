import React from "react";
import { ButtonBase, getAppColors, IconButton } from "../relic-ui";
import { CommonIcons } from "./common/icons";
import { InventoryProductWithSeller } from "../_pages/seller/seller/providers/products/product-data";
import { formatMoney } from "../utils/misc";
import { useAtom } from "jotai";
import { useCartAtom } from "../providers/cart";
import { useNavigate } from "react-router-dom";

export const noProductImageGIF =
  "https://media.tenor.com/wRSJIEb_RHMAAAAd/jab-we-met-kareena-kapoor.gif";

export const ProductCard = (props: { product: InventoryProductWithSeller }) => {
  const cartAtom = useCartAtom();
  const [cart, setCart] = useAtom(cartAtom);
  const navigate = useNavigate();

  const itemAlreadyInCart = cart.items.find((item) => {
    return item.id === props.product.id;
  });

  return (
    <div
      onClick={() => {
        navigate(`product/${props.product.id}`);
      }}
      className="w-full border border-black/20  rounded-xl flex flex-col group cursor-pointer"
    >
      <div className="w-full aspect-square relative">
        <img
          src={
            props.product?.images?.length > 0
              ? props.product?.images[0]
              : noProductImageGIF
          }
          alt=""
          width={"100%"}
          height={"100%"}
          className="object-cover w-full h-full rounded-xl"
        />

        <div className="absolute right-0 top-0 p-2 opacity-0 group-hover:opacity-100 transition-all">
          {/* Like */}
          <IconButton
            rounded="50%"
            px={12}
            py={12}
            bgColor={getAppColors().primaryContainer.css()}
            fgColor={getAppColors().onPrimaryContainer.css()}
          >
            <CommonIcons.Heart size={18} variant="Linear" />
          </IconButton>
        </div>

        <div className="absolute right-0 bottom-0 p-2 opacity-50 group-hover:opacity-100 transition-all">
          <div className="bg-tertiary text-onTertiary text-[10px] font-semibold px-1 rounded-sm flex items-center gap-[2px] transform -skew-x-12">
            <span>4.5</span>
            <CommonIcons.Star size={12} variant="Bulk" />
          </div>
        </div>
      </div>
      <div className="p-4 flex flex-col gap-1">
        <h4 className="font-semibold pb-2">{props.product?.name}</h4>

        {/*  */}

        {/* <div className="flex gap-2 items-center"></div> */}

        {/*  */}

        <div className="flex gap-1 items-baseline">
          <div className="text-2xl font-semibold">
            {formatMoney(props.product.sellingPrice)}
          </div>
          <div className="line-through italic opacity-50">
            {formatMoney(
              props.product.sellingPrice + props.product.sellingPrice * 0.12
            )}
          </div>
          <div className="italic text-tertiary text-xs">(12% off)</div>
        </div>

        <div className="flex pt-2">
          <ButtonBase
            fullWidth
            onClick={() => {
              if (itemAlreadyInCart) {
                return;
              }

              setCart((prev) => {
                return {
                  ...prev,
                  items: [...prev.items, props.product],
                };
              });
            }}
            leftIcon={<CommonIcons.ShoppingCart size={16} />}
            disabled={itemAlreadyInCart ? true : false}
          >
            {itemAlreadyInCart ? "Already in Cart!" : "Add to cart"}
          </ButtonBase>
        </div>
      </div>
    </div>
  );
};
