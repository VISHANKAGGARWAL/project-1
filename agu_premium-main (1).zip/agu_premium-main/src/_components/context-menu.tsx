import React from "react";
import { useOutsideClick } from "../utils/outside-click";

export const ContextMenu = (props: {
  options: {
    label: string;
    value: string;
  }[];
  onSelect: (value: string) => void;
  render?: (label: string, value: string, index: number) => React.ReactNode;
  children: React.ReactNode;
}) => {
  const [isOpen, setIsOpen] = React.useState(false);

  const outSideClick = useOutsideClick(() => {
    setIsOpen(false);
  });

  return (
    <div
      className="relative"
      onClick={() => setIsOpen(!isOpen)}
      //   onBlur={() => setIsOpen(false)}
      tabIndex={0}
    >
      {props.children}

      {isOpen && (
        <div
          ref={outSideClick as any}
          className="absolute top-full left-0  bg-background text-onBackground border border-surfaceVariant rounded-md shadow-md"
        >
          {props.options.map((item, index) => {
            return (
              <div
                key={index}
                className="px-4 py-2 hover:bg-surfaceVariant  cursor-pointer"
                onClick={() => {
                  props.onSelect(item.value);
                  setIsOpen(false);
                }}
              >
                {props.render
                  ? props.render(item.label, item.value, index)
                  : item.label}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
