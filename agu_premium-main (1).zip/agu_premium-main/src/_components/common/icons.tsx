import { ArrowRight, Heart, Star, Star1 } from "iconsax-react";
import { ShoppingCart, Box } from "iconsax-react";
import { IoLanguageSharp } from "react-icons/io5";
import { RiAddFill } from "react-icons/ri";
import { IoMdArrowRoundForward } from "react-icons/io";
import { GiFiles } from "react-icons/gi";
import { FcGoogle } from "react-icons/fc";
import { BiError } from "react-icons/bi";
import { FaMoneyCheckAlt } from "react-icons/fa";
import { GiHotMeal } from "react-icons/gi";
import { FaBoxes } from "react-icons/fa";
import { BsPeopleFill } from "react-icons/bs";
import { IoIosPeople } from "react-icons/io";
import { FaMoneyBillAlt } from "react-icons/fa";
import { RiMoneyDollarCircleFill } from "react-icons/ri";
import { FaFileInvoice } from "react-icons/fa";
import { HiDocumentReport } from "react-icons/hi";
import { FiSettings } from "react-icons/fi";
import { FiEdit } from "react-icons/fi";
import { MdDelete } from "react-icons/md";
import { GiNightSky } from "react-icons/gi";
import { IoIosCloudyNight } from "react-icons/io";
import { GiAllSeeingEye } from "react-icons/gi";
import { IoIosExit } from "react-icons/io";
import { HiOutlineTrendingUp } from "react-icons/hi";
import { HiOutlineTrendingDown } from "react-icons/hi";
import { RiFileList3Line } from "react-icons/ri";

export const CommonIcons = {
  ArrowRight: ArrowRight,
  Next: ArrowRight,
  ShoppingCart: ShoppingCart,
  OrdersBox: Box,
  Language: IoLanguageSharp,
  Star: Star,
  Heart: Heart,
  Error: BiError,

  //
  Add: RiAddFill,
  Files: GiFiles,
  Google: FcGoogle,
  Money: FaMoneyCheckAlt,

  //
  HotMeal: GiHotMeal,
  Boxes: FaBoxes,
  People: BsPeopleFill,
  Employees: IoIosPeople,
  Money2: FaMoneyBillAlt,
  Money3: RiMoneyDollarCircleFill,
  Invoices: FaFileInvoice,
  Reports: HiDocumentReport,
  Settings: FiSettings,
  //
  Edit: FiEdit,
  Delete: MdDelete,
  //
  NightSky: GiNightSky,
  Night: IoIosCloudyNight,
  Eye: GiAllSeeingEye,
  //
  Logout: IoIosExit,
  //
  TrendingUp: HiOutlineTrendingUp,
  TrendingDown: HiOutlineTrendingDown,
  //
  List: RiFileList3Line,
};
