import React from "react";
import { Link } from "react-router-dom";
import { useAppLang } from "../../core/app-lang";
import { useAuth } from "../../core/auth/auth-hooks";
import {
  getAppColors,
  IconButton,
  SelectBase,
  useRelicTheme,
} from "../../relic-ui";
import { Logo } from "../../_widgets/logo";
import { ContextMenu } from "../context-menu";
import { CartHeaderIcon } from "./cart-icon";
import { CommonIcons } from "./icons";
import { LanguageSelector } from "./language-selector";
import { UserCard } from "./user-card";

export const Header = () => {
  const { user } = useAuth();

  const isSeller = user?.isSeller;

  useRelicTheme();
  const t = useAppLang();

  const menuItems = [
    {
      label: t("Categories"),
      link: "/",
    },
    {
      label: t("Brands"),
      link: "/brands",
    },
    {
      label: t("FAQ"),
      link: "/",
    },
    {
      label: isSeller ? t("Seller Portal") : t("Become a Seller"),
      link: "/seller",
    },
  ];

  return (
    <div className="border-b border-surfaceVariant h-[80px] flex items-center justify-center px-8 ">
      <div className="flex items-center justify-between max-w-7xl w-full">
        {/* Left */}

        <div className="flex items-center gap-[60px]">
          <Link to={"/home"}>
            <Logo />
          </Link>

          {/* Menu */}

          <div className=" items-center hidden md:flex">
            {menuItems.map((item, index) => {
              return (
                <Link key={index} to={item.link}>
                  <div className="opacity-70 hover:opacity-100 px-4 py-2 transition-all hover:italic hover:scale-105">
                    {item.label}
                  </div>
                </Link>
              );
            })}
          </div>
        </div>

        {/* Right */}

        <div className="flex items-center gap-5">
          <CartHeaderIcon />

          <IconButton
            rounded="50%"
            px={12}
            py={12}
            bgColor={getAppColors().primary.alpha(0.2).css()}
          >
            <CommonIcons.OrdersBox size={18} />
          </IconButton>

          <div className="hidden md:block">
            <UserCard />
          </div>

          <LanguageSelector />
        </div>
      </div>
    </div>
  );
};
