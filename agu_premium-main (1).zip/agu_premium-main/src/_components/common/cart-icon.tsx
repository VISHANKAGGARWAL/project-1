import React from "react";
import { getAppColors, IconButton, useRelicTheme } from "../../relic-ui";
import { CommonIcons } from "./icons";
import { useCartAtom } from "../../providers/cart";
import { useAtom } from "jotai";
import { useLocation, useNavigate } from "react-router-dom";

export const CartHeaderIcon = () => {
  const location = useLocation();

  useRelicTheme();

  const cartAtom = useCartAtom();
  const [cart, setCart] = useAtom(cartAtom);
  const navigate = useNavigate();

  return (
    <div className="relative">
      <IconButton
        rounded="50%"
        px={12}
        py={12}
        bgColor={getAppColors().tertiary.alpha(0.2).css()}
        fgColor={getAppColors().tertiary.css()}
        disabled={cart.items.length === 0}
        onClick={() => {
          const isHome = location.pathname.split("/")[1] === "home";
          if (isHome) {
            navigate("/home/cart");
          } else {
            navigate(`/${location.pathname.split("/")[1]}/cart`);
          }
        }}
      >
        <CommonIcons.ShoppingCart size={18} />
      </IconButton>

      {cart.items.length > 0 && (
        <div className="absolute bottom-0 right-0">
          <div className="bg-tertiary text-onTertiary rounded-full w-4 h-4 flex items-center justify-center text-xs select-none">
            {cart.items.length}
          </div>
        </div>
      )}
    </div>
  );
};
