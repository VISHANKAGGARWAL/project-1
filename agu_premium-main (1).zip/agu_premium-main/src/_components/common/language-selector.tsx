import React from "react";
import { useAppLang, appLang } from "../../core/app-lang";
import { IconButton } from "../../relic-ui";
import { ContextMenu } from "../context-menu";
import { CommonIcons } from "./icons";

export const LanguageSelector = () => {
  const t = useAppLang();

  return (
    <ContextMenu
      options={[
        {
          label: t("English"),
          value: "en",
        },
        {
          label: t("Hindi (हिंदी)"),
          value: "hi",
        },
        {
          label: t("Japanese (日本語)"),
          value: "jp",
        },
      ]}
      onSelect={(value) => {
        appLang.changeLang(value);
      }}
    >
      <IconButton rounded="50%" px={12} py={12} bgColor={"#00000000"}>
        <CommonIcons.Language size={18} />
      </IconButton>
    </ContextMenu>
  );
};
