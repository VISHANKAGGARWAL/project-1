import React from "react";
import { useNavigate } from "react-router-dom";
import { useAppLang } from "../../core/app-lang";
import { useAuth } from "../../core/auth/auth-hooks";

export const UserCard = (props: {}) => {
  const auth = useAuth();
  const navigate = useNavigate();

  const t = useAppLang();

  return (
    <div
      onClick={() => {
        if (!auth.user) {
          navigate("/auth");
        }
      }}
      className="flex items-center gap-2 border border-surfaceVariant p-1 rounded-full pr-6 select-none cursor-pointer hover:opacity-75"
    >
      {/* Avatar */}
      <div className="w-11 h-11 bg-gray-300 rounded-full"></div>

      {/* Right */}

      <div className="flex flex-col justify-center items-start">
        <span className="opacity-50 text-xs">{t("Hi, Welcome")}</span>
        <span className="font-bold">{auth.user?.name ?? "Login"}</span>
      </div>
    </div>
  );
};
