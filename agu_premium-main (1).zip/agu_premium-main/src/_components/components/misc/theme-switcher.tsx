import React from "react";
import { useRelicTheme } from "../../../relic-ui";

export const ThemeSwitcher = () => {
  const theme = useRelicTheme();

  return (
    <div>
      <button onClick={() => theme.toggleThemeMode()}>Theme</button>
    </div>
  );
};
