import React from "react";

import chroma from "chroma-js";
import { getAppColorsString, useRelicTheme } from "../../../relic-ui";
import { CommonIcons } from "../../common/icons";

export const ErrorContainer = (props: {
  children?: React.ReactNode;
  errorTitle?: string;
  error?: string;
}) => {
  useRelicTheme();

  return (
    <div
      style={{
        backgroundColor: chroma(getAppColorsString().onErrorContainer)
          .alpha(0.1)
          .css(),
      }}
      className="flex flex-col items-center justify-center
         text-onErrorContainer rounded-2xl px-8 py-4 select-none"
    >
      {/*  */}
      <CommonIcons.Error size={60} />
      <h3 className="pt-4 font-semibold text-base">
        {props.errorTitle ?? "Error!"}
      </h3>
      <p className="pt-3">
        {props.error ?? "We caught an error, you might not be interested in..."}
      </p>
      {props.children}
    </div>
  );
};
