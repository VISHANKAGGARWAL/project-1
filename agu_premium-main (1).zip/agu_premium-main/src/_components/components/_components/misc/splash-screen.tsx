import { css } from "@emotion/react";
import React from "react";

export const SplashScreen = (props: { onComplete: () => void }) => {
  return <></>;
};
