import chroma from "chroma-js";
import React from "react";
import { ButtonBase } from "../../relic-ui";
import { CommonIcons } from "../common/icons";
import { InventoryProduct } from "../../_pages/seller/seller/providers/products/product-data";
import { formatMoney } from "../../utils/misc";
import { noProductImageGIF } from "../product-card";
import { useNavigate } from "react-router-dom";

export const Banner = (props: { product?: InventoryProduct }) => {
  const navigate = useNavigate();
  return (
    <div className="w-full flex justify-center">
      <div className="w-full max-w-7xl relative pt-8 ">
        {/*  */}

        <div className="w-full h-[60vh] relative overflow-clip">
          <img
            src={
              (props.product?.images ?? []).length > 0
                ? props.product?.images[0]
                : noProductImageGIF
            }
            alt="Sponsered"
            width="100%"
            height={"100%"}
            className="object-cover w-full h-full  rounded-3xl "
          />

          <div
            className="flex flex-col absolute top-0 left-0
             m-4 w-full max-w-[500px] gap-5
          "
          >
            <div className="bg-gradient-to-b from-black/20 backdrop-blur-2xl to-white/20 p-8 text-white rounded-3xl">
              <h1 className="text-6xl font-semibold">{props.product?.name}</h1>

              <p className="pt-4">{props.product?.description}</p>
            </div>

            <div className="flex gap-4 w-full max-w-[500px]">
              <div
                className="h-[150px] p-2 flex items-center justify-center
                    rounded-3xl backdrop-blur-3xl text-5xl w-full text-white font-bold
                "
              >
                {formatMoney(props.product?.sellingPrice ?? 0)}
              </div>

              <div className="w-[150px] h-[150px] flex-none">
                <ButtonBase
                  fullWidth
                  fullHeight
                  rippleShape="square"
                  rounded="24px"
                  bgColor={chroma("red").alpha(0.4).css()}
                  fgColor="white"
                  className="backdrop-blur-3xl font-bold"
                  onClick={() => {
                    navigate(`product/${props.product?.id}`);
                  }}
                >
                  <div className="flex flex-col gap-4 items-center">
                    <CommonIcons.ShoppingCart size={40} />
                    <span className="font-bold">Buy Now</span>
                  </div>
                </ButtonBase>
              </div>
            </div>
          </div>
        </div>

        {/*  */}
      </div>
    </div>
  );
};
