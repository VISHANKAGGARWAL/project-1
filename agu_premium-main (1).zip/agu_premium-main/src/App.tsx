import { useState } from "react";
import { BrowserRouter, Routes } from "react-router-dom";
import { AppLangProvider } from "./core/app-lang";
import { AGUDevTools } from "./core/dev/dev-tools";
import { Firebase } from "./core/firebase/firebase";
import { RelicDeveloperTools, ThemeProvider } from "./relic-ui";
import { EntryPage } from "./_pages/_entry/entry";
import { QueryClient, QueryClientProvider } from "react-query";

Firebase.getInstance().initilize();

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: false,
      refetchOnMount: false,
    },
  },
});

function App() {
  return (
    <ThemeProvider>
      <QueryClientProvider client={queryClient}>
        <AppLangProvider>
          {/* MAIN Router */}

          <BrowserRouter>
            <EntryPage />
          </BrowserRouter>
        </AppLangProvider>
        {/* DevTools */}

        {/* <RelicDeveloperTools>
          <AGUDevTools />
        </RelicDeveloperTools> */}
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
