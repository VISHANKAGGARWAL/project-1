declare module "*.jpg" {
  const content: any;
  export const ReactComponent: any;
  export default content;
}
