import React from "react";
import { removeKeys } from "../../utils/misc";
import { InputBase } from "../input/input-base";
import { RelicFormFieldRef } from "./form.hooks";

type AutoOptions = {
  type?: "string" | "number" | "boolean" | "object" | "array";
  label?: string;
  props?: any;
  auto?: "auto";
};

export function auto(options?: AutoOptions) {
  return options ?? { type: "string", label: "label", props: {}, auto: "auto" };
}

type AutoElem = JSX.Element;
export function automaticElement(options?: AutoOptions): AutoElem {
  return <InputBase label={options?.label} />;
}

type FeildsObject<T> = {
  [K in keyof T]: JSX.Element | AutoOptions;
};

///
///

export type FormProps = React.ClassAttributes<HTMLFormElement> &
  React.FormHTMLAttributes<HTMLFormElement>;

const _removeProps = {
  children: undefined,
  feilds: undefined,
  onSubmitData: undefined,
  formData: undefined,
};

export type RelicFormProps<T> = {
  children?: React.ReactNode;
  feilds: FeildsObject<T>;
  onSubmitData?: (data: T) => void;
  formData?: { [K in keyof T]: T[K] | any };
};
export type RelicFormPropsMixed<T> = FormProps & RelicFormProps<T>;

///
///

export function Form<T>(props: RelicFormPropsMixed<T>) {
  const formProps = removeKeys<RelicFormPropsMixed<T>>(props, _removeProps);

  const refs: { [key: string]: React.RefObject<RelicFormFieldRef<any>> } =
    Object.keys(props.feilds!).reduce((acc, key) => {
      // acc[key] = React.useRef<RelicInputRef>(null);
      acc[key] = React.createRef<RelicFormFieldRef<any>>();
      return acc;
    }, {} as any);

  //

  return (
    <form
      {...formProps}
      onSubmit={(e) => {
        e.preventDefault();
        const data = Object.keys(props.feilds!).reduce((acc, key) => {
          acc[key] = refs[key]!.current!.value;
          return acc;
        }, {} as any);
        props.onSubmitData?.(data);
      }}
    >
      {/*  */}

      {props.feilds &&
        Object.keys(props.feilds).map((key) => {
          const feild = (props.feilds! as any)[key] as
            | JSX.Element
            | AutoOptions;

          const isElement = "$$typeof" in feild;

          if (!isElement) {
            const _feild = feild as AutoOptions;
            return React.cloneElement(
              automaticElement({
                type: _feild.type ?? "string",
                label: _feild.label,
              } as AutoOptions),
              {
                ref: refs[key],
                key,
                value: props.formData?.[key as keyof T],
                ..._feild.props,
              }
            );
          }

          const _feild = feild as JSX.Element;

          // return React.createElement(_feild.type, {
          //   ..._feild.props,
          //   ref: refs[key],
          //   key,
          // });

          return React.cloneElement(_feild, {
            ref: refs[key],
            key,
            value: props.formData?.[key as keyof T] ?? _feild.props.value,
          });
        })}

      <input type={"submit"} value={"Submit"} />
    </form>
  );
}
