import chroma from "chroma-js";
import { useMotionValue } from "framer-motion";
import React, { useEffect } from "react";

export const GridRipple = (props: {
  cellSize?: number;
  duration?: number;
  shape?: {
    x: number;
    y: number;
  };
  color?: string;
  opacityMultiplier?: number;
  rippleRadius?: number;
  rippleRadiusMultiplier?: number;
  thickness?: number;
  animation?: "random";
  animationDuration?: number;
}) => {
  const canvasParentRef = React.useRef<HTMLDivElement>(null);
  const canvasRef = React.useRef<HTMLCanvasElement>(null);

  const [startRipplePos, setStartRipplePos] = React.useState<{
    x: number;
    y: number;
  } | null>(null);

  //
  const rippleDuration = props.duration ?? 5000;
  const cellSize = props.cellSize ?? 20;
  const shape = props.shape ?? { x: 1, y: 1 };
  const thickness = (props.thickness ?? 0.2) * -1;

  //

  const w = React.useRef(0);
  const h = React.useRef(0);

  // Initial setup
  React.useEffect(() => {
    const parent = canvasParentRef.current;
    const canvas = canvasRef.current;

    if (!parent || !canvas) return;

    const rect = canvasParentRef.current.getBoundingClientRect();
    w.current = rect.width;
    h.current = rect.height;

    canvas.width = w.current;
    canvas.height = h.current;
  }, [
    canvasParentRef.current?.clientWidth,
    canvasParentRef.current?.clientHeight,
  ]);

  // Main loop
  React.useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;

    // There's no Ripple Posiition
    if (startRipplePos === null) {
      return;
    }

    // Max Ripple Radius
    const maxRippleSize =
      props.rippleRadius ??
      Math.max(w, h) * (props.rippleRadiusMultiplier ?? 1);

    const startTime = Date.now();
    const countX = Math.ceil(w / cellSize);
    const countY = Math.ceil(h / cellSize);

    let animationFrameId: number | undefined = undefined;

    const draw = () => {
      const now = Date.now();
      const timeDiff = now - startTime;

      // tracks the progress of the ripple animation (0-1)
      const progress = Math.min(timeDiff / rippleDuration, 1);

      ctx.clearRect(0, 0, w, h);

      for (let i = 0; i < countX; i++) {
        for (let j = 0; j < countY; j++) {
          const x = i * cellSize;
          const y = j * cellSize;

          // Distance from the ripple center multiplied by the ripple shape (to make something oval)
          const dist = Math.sqrt(
            Math.pow(x - startRipplePos.x, 2) * shape.y +
              Math.pow(y - startRipplePos.y, 2) * shape.x
          );

          //
          const rDist = dist - progress * maxRippleSize;

          // Ripple Progress
          let rippleProgress = Math.min(rDist / cellSize, 1);

          // Negative to Positive to make it look like a wave
          if (rippleProgress < thickness) {
            rippleProgress *= -1;
          }

          //   draw a text
          // ctx.font = "8px Arial";
          // ctx.fillStyle = "red";
          // ctx.fillText(rippleProgress.toFixed(1), x + 5, y - 5);

          //
          const color = Math.floor(255 - rippleProgress * 255);

          // Only draws the ripple if it has color value
          if (color > 1) {
            ctx.fillStyle = chroma(props.color ?? "white")
              .alpha(
                (1 - rippleProgress) *
                  (props.opacityMultiplier ?? 1) *
                  (1 - progress)
              )
              .css();

            ctx.fillRect(x, y, cellSize, cellSize);
          }
        }
      }

      // If the ripple is still animating, keep drawing
      if (progress < 1) {
        animationFrameId = requestAnimationFrame(draw);
      } else {
        setStartRipplePos(null);
      }
    };

    draw();
    return () => {
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    startRipplePos,
    // props.color,
    // props.cellSize,
    // props.shape,
    // props.rippleRadius,
    // props.rippleRadiusMultiplier,
    // props.opacityMultiplier,
    // props.thickness,
  ]);

  // Animation Randome
  React.useEffect(() => {
    if (props.animation !== "random") return;
    if (!canvasParentRef.current) return;

    const timeout = setTimeout(() => {
      setStartRipplePos({
        x: Math.random() * w.current,
        y: Math.random() * h.current,
      });
    }, props.animationDuration ?? 500);

    return () => {
      clearTimeout(timeout);
    };
  }, [startRipplePos, props.animation, props.animationDuration]);

  return (
    <div
      ref={canvasParentRef}
      onMouseDown={(e) => {
        if (props.animation) return;

        const rect = e.currentTarget.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        setStartRipplePos({
          x: x - cellSize / 2,
          y: y - cellSize / 2,
        });
      }}
      className="w-full h-full"
    >
      <canvas className="w-full h-full" ref={canvasRef} />
    </div>
  );
};
