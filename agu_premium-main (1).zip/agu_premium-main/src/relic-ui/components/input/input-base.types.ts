import { RelicFormFieldRef } from "../form/form.hooks";

export interface RelicInputRef<T> extends RelicFormFieldRef<T> {
  get value(): T;
  set value(value: T);
  get numberValue(): number;
  get element(): HTMLElement | null;
  validate(): boolean;
  setError(error: string | null): void;
}
