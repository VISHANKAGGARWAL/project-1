import { Interpolation, Theme } from "@emotion/react";
import styled from "@emotion/styled";
import React from "react";
import { getAppColorsString } from "../../theme/theme";
import { useRelicTheme } from "../../theme/theme.hooks";
import { removeKeys } from "../../utils/misc";
import { RelicInputRef } from "./input-base.types";
import "./input.css";

///
export type InputProps = React.ClassAttributes<HTMLInputElement> &
  React.InputHTMLAttributes<HTMLInputElement>;

const _props = {
  px: undefined as number | undefined,
  py: undefined as number | undefined,

  bgColor: undefined as string | undefined,
  fgColor: undefined as string | undefined,
  hoverBgColor: undefined as string | undefined,
  hoverFgColor: undefined as string | undefined,

  borderColor: undefined as string | undefined,
  borderWidth: undefined as string | undefined,
  activeBorderColor: undefined as string | undefined,
  border: undefined as string | undefined,

  leftIcon: undefined as React.ReactNode | undefined,
  rightIcon: undefined as React.ReactNode | undefined,
  alwaysShowRightIcon: undefined as boolean | undefined,

  rounded: undefined as number | undefined,
  fullWidth: undefined as boolean | undefined,
  //
  validator: undefined as
    | ((value: string) => string | void | undefined | null)
    | undefined,
  label: undefined as string | undefined,
  onSubmit: undefined as ((value: string) => void) | undefined,
  value: undefined as any | undefined,
};
export type RelicInputProps = Partial<typeof _props>;

export type RelicInputPropsMixed = InputProps & RelicInputProps;

export const removeInputPropsFromRelicProps = <T,>(props: T) => {
  return removeKeys<T>(props, _props);
};

///
///
///

export const useInputController = <T extends any>() =>
  React.useRef<RelicInputRef<T>>(null);

///
///

export const InputBase = React.forwardRef<
  RelicInputRef<any>,
  RelicInputPropsMixed
>((props, ref) => {
  ///
  const inputProps = removeInputPropsFromRelicProps(props);

  ///
  const [value, setValue] = React.useState<any>(props.value ?? "");
  //
  const [labelShown, setLabelShown] = React.useState(!!value);
  const [error, setError] = React.useState<string | null>(null);

  React.useImperativeHandle(ref, () => ({
    get value() {
      return value;
    },
    set value(value) {
      setValue(value);
    },
    get numberValue() {
      return Number(value);
    },
    get element() {
      return null;
    },
    validate() {
      setError(null);
      if (value) {
        let res: string | null = null;
        if (props.disabled) {
          return true;
        }
        if (props.validator) {
          const r = props.validator(value);
          if (r) {
            res = r;
          }
        }
        if (res == null) {
          return true;
        }
        setError(res);
        return false;
      }
      return true;
    },
    setError(error: string | null) {
      setError(error);
    },
  }));

  useRelicTheme();

  /// Colors

  let bgColor = props.bgColor ?? getAppColorsString().surface20;
  let fgColor = props.fgColor ?? getAppColorsString().onSurfaceVariant;
  let borderColor = props.borderColor ?? getAppColorsString().surfaceVariant40;
  let activeBorderColor =
    props.activeBorderColor ?? getAppColorsString().surfaceVariant60;
  let border = props.border ?? "2px solid";
  let borderWidth = props.borderWidth ?? "2px";

  let px = props.px ?? 8;
  let py = props.py ?? 6;

  // if (isDisabled) {
  //   bgColor = getAppColors().surfaceVariant;
  //   fgColor = getAppColors().onSurfaceVariant;
  // }

  /// Styled
  ///
  const SInputDiv = React.useMemo(
    () =>
      styled.div`
        background-color: ${bgColor};
        color: ${fgColor};

        border-radius: ${props.rounded ?? 6}px;
        border: ${border};
        border-width: ${borderWidth};
        border-color: ${borderColor};
        padding: ${py}px ${px}px;

        &:focus-within {
          border-color: ${activeBorderColor};
        }
      `,
    [bgColor, fgColor, props.rounded]
  );

  return (
    <div
      className={`
        transition-all relative  pt-4 
          ${labelShown ? "" : ""}
            ${props.className || ""}

            ${
              props.disabled
                ? "opacity-70 pointer-events-none select-none "
                : ""
            }
        `}
    >
      <div className="relative transition-all">
        <SInputDiv
          className={`
      outline-none
      ${error !== null ? "border-error focus-within:border-error" : ""} 
        transition-all flex items-center space-x-2 w-full
      `}
        >
          {props.leftIcon}
          <input
            {...inputProps}
            className={`bg-transparent outline-none transition-all
             placeholder:text-surfaceVariant60 placeholder:opacity-80 w-full
            `}
            placeholder={labelShown ? props.placeholder : ""}
            value={value}
            onChange={(e) => {
              setValue(e.target.value);
              if (props.label) {
                setLabelShown(!!e.target.value);
              }
              setError(null);
              props.onChange && props.onChange(e);
            }}
            onFocus={(e) => {
              if (props.label) {
                setLabelShown(true);
              }
              props.onFocus && props.onFocus(e);
            }}
            onBlur={(e) => {
              if (props.label) {
                setLabelShown(!!e.target.value);
              }
              props.onBlur && props.onBlur(e);
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                props.onSubmit && props.onSubmit(value || "");
              }
              props.onKeyDown && props.onKeyDown(e);
            }}
          />
          {(labelShown || props.alwaysShowRightIcon) && props.rightIcon}
        </SInputDiv>
        <label
          className={[
            ` absolute  top-0  bottom-0 flex items-center text-surfaceVariant60 opacity-90
              transition-all duration-200 ease-in-out pointer-events-none `,
            labelShown
              ? ` top-[-150%]  left-1 text-xs`
              : ` ${props.leftIcon ? "left-8" : "left-3"}  `,
          ].join(" ")}
        >
          {props.label}
        </label>
      </div>

      {error && (
        <div className="flex gap-[3px] items-center text-xs px-1 text-error mt-[2px]">
          <span>
            <p>ERROROROROR ICON</p>
          </span>
          <span className="pt-[1px]">{error}</span>
        </div>
      )}
    </div>
  );
});
