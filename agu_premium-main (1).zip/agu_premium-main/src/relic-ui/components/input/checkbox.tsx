import React from "react";
import { RelicInputRef } from "../input/input-base.types";

export type RelicCheckboxProps = {
  value?: boolean;
  onChange?: (value: boolean, event?: HTMLElement) => void;
  children?: React.ReactNode;
  toggleOnLeftSide?: boolean;
  disabled?: boolean;
  validator?: (value: boolean) => string | void;
  onText?: React.ReactNode;
  offText?: React.ReactNode;
  groupName?: string;
};

///
///

export const Checkbox = React.forwardRef<
  RelicInputRef<boolean>,
  RelicCheckboxProps
>((props, ref) => {
  ///
  const [value, setValue] = React.useState<boolean>(props.value ?? false);
  //
  const [error, setError] = React.useState<string | null>(null);

  React.useImperativeHandle(ref, () => ({
    get value() {
      return value;
    },
    set value(value) {
      setValue(value);
    },
    get numberValue() {
      return Number(value);
    },
    get element() {
      return null;
    },
    validate() {
      setError(null);
      if (value) {
        let res: string | null = null;
        if (props.disabled) {
          return true;
        }
        if (props.validator) {
          const r = props.validator(value);
          if (r) {
            res = r;
          }
        }
        if (res == null) {
          return true;
        }
        setError(res);
        return false;
      }
      return true;
    },
    setError(error: string | null) {
      setError(error);
    },
  }));

  return (
    <div className="flex flex-col py-2">
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium select-none felx items-center gap-1">
          <span>{props.children}</span>
          <span>{value ? props.onText : props.offText}</span>
        </span>
        <input
          type="checkbox"
          className="w-4 h-4 text-primary accent-primary bg-surfaceVariant rounded"
          checked={value}
          onChange={(e) => {
            setValue(e.target.checked);
            setError(null);
            props.onChange && props.onChange(e.target.checked, e.target);
          }}
        />
      </div>
      {error && (
        <div className="text-xs  text-error mt-[2px] select-none">{error}</div>
      )}
    </div>
  );
});
