import React from "react";
import { RelicInputProps, removeInputPropsFromRelicProps } from "./input-base";
import { RelicInputRef } from "./input-base.types";
import "./input.css";

///
export type TextAreaProps = React.ClassAttributes<HTMLTextAreaElement> &
  React.InputHTMLAttributes<HTMLTextAreaElement>;

export type RelicTextAreaPropsMixed = TextAreaProps & RelicInputProps;

///
///

export const TextArea = React.forwardRef<
  RelicInputRef<any>,
  RelicTextAreaPropsMixed
>((props, ref) => {
  ///
  const textAreaProps =
    removeInputPropsFromRelicProps<RelicTextAreaPropsMixed>(props);

  ///
  const [value, setValue] = React.useState<any>(props.value ?? "");
  //
  const [labelShown, setLabelShown] = React.useState(!!value);
  const [error, setError] = React.useState<string | null>(null);

  React.useImperativeHandle(ref, () => ({
    get value() {
      return value;
    },
    set value(value) {
      setValue(value);
    },
    get numberValue() {
      return Number(value);
    },
    get element() {
      return null;
    },
    validate() {
      setError(null);
      if (value) {
        let res: string | null = null;
        if (props.disabled) {
          return true;
        }
        if (props.validator) {
          const r = props.validator(value);
          if (r) {
            res = r;
          }
        }
        if (res == null) {
          return true;
        }
        setError(res);
        return false;
      }
      return true;
    },
    setError(error: string | null) {
      setError(error);
    },
  }));

  return (
    <div
      className={`
        transition-all relative  pt-4 
          ${labelShown ? "" : ""}
            ${props.className || ""}

            ${
              props.disabled
                ? "opacity-70 pointer-events-none select-none "
                : ""
            }
        `}
    >
      <div className="relative transition-all">
        <div
          className={`px-2 py-[6px] rounded-md
      bg-surface20 text-onSurfaceVariant
      outline-none border-2 
      ${
        error !== null
          ? "border-error focus-within:border-error"
          : "border-surfaceVariant40 focus-within:border-surfaceVariant60"
      } 
      transition-all flex items-center space-x-2 w-full
      `}
        >
          {props.leftIcon}
          <textarea
            {...textAreaProps}
            className={`bg-transparent outline-none transition-all
             placeholder:text-surfaceVariant60 placeholder:opacity-80 w-full
            `}
            placeholder={labelShown ? props.placeholder : ""}
            value={value}
            onChange={(e) => {
              setValue(e.target.value);
              if (props.label) {
                setLabelShown(!!e.target.value);
              }
              setError(null);
              props.onChange && props.onChange(e);
            }}
            onFocus={(e) => {
              if (props.label) {
                setLabelShown(true);
              }
              props.onFocus && props.onFocus(e);
            }}
            onBlur={(e) => {
              if (props.label) {
                setLabelShown(!!e.target.value);
              }
              props.onBlur && props.onBlur(e);
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                props.onSubmit && props.onSubmit(value || "");
              }
              props.onKeyDown && props.onKeyDown(e);
            }}
          />
          {(labelShown || props.alwaysShowRightIcon) && props.rightIcon}
        </div>
        <label
          className={[
            ` absolute  top-0  bottom-0 flex items-center text-surfaceVariant60 opacity-90
              transition-all duration-200 ease-in-out pointer-events-none `,
            labelShown
              ? ` top-[calc(-100%-20px)]  left-1 text-xs`
              : ` ${props.leftIcon ? "left-8" : "left-3"}  `,
          ].join(" ")}
        >
          {props.label}
        </label>
      </div>

      {error && (
        <div className="flex gap-[3px] items-center text-xs px-1 text-error mt-[2px]">
          <span>
            <p>ERROROROROR ICON</p>
          </span>
          <span className="pt-[1px]">{error}</span>
        </div>
      )}
    </div>
  );
});
