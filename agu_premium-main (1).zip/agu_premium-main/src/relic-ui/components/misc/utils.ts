/**
 * @deprecated
 */
export function filterTailwindClassName(
  originalClassName: string,
  newClassName: string
): string {
  // remove from originalClassName all classes that are in newClassName
  const originalClasses = originalClassName.split(" ").map((c) => c.trim());
  const newClasses = newClassName.split(" ").map((c) => c.trim());

  // key is tailwind class prefix (eg. text, bg, border, etc.)
  // value is array of tailwind classes value (eg. red-500, green-500, etc.)
  const classesMap: {
    [key: string]: string[];
  } = {};
  const unknownClasses: string[] = [];

  //

  originalClasses.forEach((c) => {
    const split = c.split("-");
    if (split.length < 2) {
      unknownClasses.push(c);
    } else {
      const prefix = split[0];
      const value = split.slice(1).join("-");
      if (classesMap[prefix]) {
        classesMap[prefix].push(value);
      } else {
        classesMap[prefix] = [value];
      }
    }
  });
  // TODO:

  return "";
}
