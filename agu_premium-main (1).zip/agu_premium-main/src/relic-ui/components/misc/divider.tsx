import chroma from "chroma-js";
import React from "react";
import { getAppColorsString } from "../../theme/theme";
import { useRelicTheme } from "../../theme/theme.hooks";

export const Divider = (props: {
  thickness?: number | string;
  height?: number;
  color?: string;
  style?: React.CSSProperties;
  children?: React.ReactNode;
  spacing?: number | string;
}) => {
  useRelicTheme();

  const color =
    props.color ??
    chroma(getAppColorsString().onSurfaceVariant).alpha(0.3).css();

  const thickness = props.thickness ?? 1;

  const divider = (
    <div
      className="w-full"
      style={{
        paddingTop: (props.height ?? 8) / 2,
        paddingBottom: (props.height ?? 8) / 2,
      }}
    >
      <div
        className="w-full"
        style={{
          height: thickness,
          backgroundColor: color,
          ...props.style,
        }}
      ></div>
    </div>
  );

  if (props.children === undefined) {
    return divider;
  }

  return (
    <div
      className="w-full flex items-center select-none"
      style={{
        color: color,
        gap: props.spacing ?? 8,
      }}
    >
      {divider}
      <div className="flex items-center text-[10px] flex-none">
        {props.children}
      </div>
      {divider}
    </div>
  );
};
