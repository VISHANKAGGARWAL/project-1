import React, { useState } from "react";
import { useRelicTheme } from "../../theme/theme.hooks";
import { ButtonBase } from "../button/button";

export const RelicDeveloperTools = (props: {
  children?: React.ReactNode;
  disable?: boolean;
}) => {
  const theme = useRelicTheme();

  const [isShown, setIsShown] = useState(false);

  if (props.disable) {
    return null;
  }

  return (
    <div className="absolute bottom-0 left-0 right-0 p-4 flex justify-end w-full">
      {!isShown && (
        <ButtonBase onClick={() => setIsShown(true)}>Dev</ButtonBase>
      )}

      {isShown && (
        <div
          className="bg-background text-onBackground overflow-hidden rounded-lg shadow-lg w-full
            flex flex-col border border-primary
        "
        >
          <div className="bg-surface text-onSurface flex justify-end items-center p-1 gap-1">
            <ButtonBase
              onClick={() => {
                theme.toggleThemeMode();
              }}
            >
              Toggle Theme
            </ButtonBase>

            <ButtonBase onClick={() => setIsShown(false)}>X</ButtonBase>
          </div>

          {props.children}
        </div>
      )}
    </div>
  );
};
