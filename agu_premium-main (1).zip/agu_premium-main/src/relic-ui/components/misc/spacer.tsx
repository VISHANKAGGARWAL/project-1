import React from "react";

export const Spacer = (
  props: {
    h?: number | string;
    w?: number | string;
  } & React.HTMLAttributes<HTMLDivElement>
) => {
  const { h, w, ...restProps } = props;
  return (
    <div
      {...restProps}
      style={{
        ...props.style,
        height: props.h,
        width: props.w,
      }}
    />
  );
};
