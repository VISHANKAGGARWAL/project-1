import React from "react";
import { RelicInputRef } from "../input/input-base.types";

export type RelicToggleButtonProps = {
  value?: boolean;
  onChange?: (value: boolean, event?: HTMLElement) => void;
  children?: React.ReactNode;
  toggleOnLeftSide?: boolean;
  disabled?: boolean;
  validator?: (value: boolean) => string | void;
  onText?: React.ReactNode;
  offText?: React.ReactNode;
};

///
///

export const ToggleButton = React.forwardRef<
  RelicInputRef<boolean>,
  RelicToggleButtonProps
>((props, ref) => {
  ///
  const [value, setValue] = React.useState<boolean>(props.value ?? false);
  //
  const [error, setError] = React.useState<string | null>(null);

  React.useImperativeHandle(ref, () => ({
    get value() {
      return value;
    },
    set value(value) {
      setValue(value);
    },
    get numberValue() {
      return Number(value);
    },
    get element() {
      return null;
    },
    validate() {
      setError(null);
      if (value) {
        let res: string | null = null;
        if (props.disabled) {
          return true;
        }
        if (props.validator) {
          const r = props.validator(value);
          if (r) {
            res = r;
          }
        }
        if (res == null) {
          return true;
        }
        setError(res);
        return false;
      }
      return true;
    },
    setError(error: string | null) {
      setError(error);
    },
  }));

  return (
    <div className="flex flex-col py-2">
      <label className="inline-flex justify-between relative items-center cursor-pointer">
        <input
          type="checkbox"
          checked={value}
          className="sr-only peer"
          onChange={(e) => {
            setValue(e.target.checked);
            setError(null);
            props.onChange && props.onChange(e.target.checked, e.target);
          }}
        />
        <span className="text-xs font-medium select-none felx items-center gap-1">
          <span>{props.children}</span>
          <span>{value ? props.onText : props.offText}</span>
        </span>
        <div
          className="w-11 h-6 bg-surfaceVariant relative
          peer-focus:outline-none 
            rounded-full peer  peer-checked:after:translate-x-full 
        peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] 
        after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full 
        after:h-5 after:w-5 after:transition-all
        peer-checked:bg-primary"
        ></div>
      </label>
      {error && (
        <div className="text-xs  text-error mt-[2px] select-none">{error}</div>
      )}
    </div>
  );
});
