import React from "react";
import { getAppColorsString } from "../../theme/theme";
import { useRelicTheme } from "../../theme/theme.hooks";
import { ButtonBase, RelicButtonPropsMixed } from "./button";

export const IconButton = (props: RelicButtonPropsMixed) => {
  useRelicTheme();

  const bgColor = props.bgColor ?? getAppColorsString().surface20;
  const fgColor = props.fgColor ?? getAppColorsString().primary;

  const px = props.px ?? 6;
  const py = props.py ?? 6;

  return (
    <ButtonBase {...props} px={px} py={py} bgColor={bgColor} fgColor={fgColor}>
      {props.children}
    </ButtonBase>
  );
};
