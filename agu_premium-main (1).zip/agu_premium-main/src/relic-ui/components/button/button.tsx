import { Interpolation, Theme } from "@emotion/react";
import styled from "@emotion/styled";
import React from "react";
import chroma from "chroma-js";
import { motion } from "framer-motion";
import { getAppColorsString } from "../../theme/theme";
import { GridRipple } from "../effects/grid-ripple";
import { useRelicTheme } from "../../theme/theme.hooks";
import { removeKeys } from "../../utils/misc";

export type ButtonProps = React.ClassAttributes<HTMLButtonElement> &
  React.ButtonHTMLAttributes<HTMLButtonElement>;

const _props = {
  px: undefined as number | undefined,
  py: undefined as number | undefined,
  bgColor: undefined as string | undefined,
  fgColor: undefined as string | undefined,
  hoverBgColor: undefined as string | undefined,
  hoverFgColor: undefined as string | undefined,
  leftIcon: undefined as React.ReactNode | undefined | "add",
  rightIcon: undefined as React.ReactNode | undefined | "next",
  loading: undefined as boolean | undefined,
  loadingText: undefined as React.ReactNode | undefined,
  rounded: undefined as number | undefined | string,
  fullWidth: undefined as boolean | undefined,
  fullHeight: undefined as boolean | undefined,
  border: undefined as string | undefined,
  rippleShape: undefined as "square" | undefined,
};
export type RelicButtonProps = Partial<typeof _props>;
export type RelicButtonPropsMixed = ButtonProps & RelicButtonProps;

//

export const ButtonBase = (props: RelicButtonPropsMixed) => {
  const buttonProps = removeKeys<RelicButtonPropsMixed>(props, _props);

  useRelicTheme();

  ///State
  const isDisabled = props.disabled || props.loading;

  /// Colors
  let bgColor = props.bgColor ?? getAppColorsString().primary;
  let fgColor = props.fgColor ?? getAppColorsString().onPrimary;
  const hoveredBgColor =
    props.hoverBgColor ?? chroma(bgColor).brighten(0.4).hex();
  const hoveredFgColor = props.hoverFgColor ?? fgColor;

  if (isDisabled) {
    bgColor = getAppColorsString().surfaceVariant;
    fgColor = getAppColorsString().onSurfaceVariant;
  }

  ///Padding
  const px = props.px ?? 12;
  const py = props.py ?? 8;

  /// Icons
  const leftIcon = props.leftIcon;
  const rightIcon = props.rightIcon;

  ///
  const SButton = React.useMemo(
    () =>
      styled.button`
        background-color: ${bgColor};
        color: ${fgColor};
        padding: ${py}px ${px}px;
        border: ${props.border ?? undefined};
        border-radius: ${(() => {
          if (props.rounded === undefined) return "6px";
          if (typeof props.rounded === "number")
            return `${props.rounded ?? 6}px`;
          return props.rounded;
        })()};
        width: ${props.fullWidth ? "100%" : "fit-content"};
        height: ${props.fullHeight ? "100%" : "fit-content"};

        pointer-events: ${isDisabled ? "none" : "auto"};
        opacity: ${isDisabled ? 0.4 : 1};

        &:hover {
          background-color: ${hoveredBgColor};
          color: ${hoveredFgColor};
        }

        &:active {
          outline: none;
          opacity: 0.85;
          background-color: ${bgColor};
          color: ${fgColor};
          scale: 0.99;
          translate: 0px 1px;
        }
      `,
    [
      bgColor,
      fgColor,
      hoveredBgColor,
      hoveredFgColor,
      isDisabled,
      props.rounded,
      px,
      py,
      props.fullWidth,
    ]
  );

  return (
    <SButton
      {...buttonProps}
      disabled={isDisabled || props.loading}
      className={`
        font-semibold
        transition-all
        flex items-center justify-center gap-[8px] 
        text-sm
        origin-bottom select-none
        relative overflow-clip  ${props.className ?? ""}
        `}
    >
      {/* Ripple Effect */}

      <div className="absolute inset-0 ">
        <GridRipple
          cellSize={12}
          duration={1500}
          shape={
            props.rippleShape === "square"
              ? {
                  x: 5,
                  y: 5,
                }
              : {
                  x: 5,
                  y: 0.8,
                }
          }
          color={fgColor}
          opacityMultiplier={props.loading ? 1 : 0.3}
          animation={props.loading ? "random" : undefined}
          animationDuration={1000}
        />
      </div>

      {/* Content */}

      <div
        style={{
          opacity: props.loading ? 0 : 1,
        }}
        className="
          flex items-center gap-[8px] 
        "
      >
        {leftIcon}
        {props.children}
        {rightIcon}
      </div>

      {/* Loading */}

      {props.loading && (
        <motion.div
          key={1}
          initial={{
            opacity: 0,
            scale: 2,
          }}
          animate={{
            opacity: 1,
            scale: 1,
          }}
          className="inset-0 absolute
        flex items-center justify-center
      "
        >
          {props.loadingText ?? "Loading.."}
        </motion.div>
      )}
    </SButton>
  );
};
