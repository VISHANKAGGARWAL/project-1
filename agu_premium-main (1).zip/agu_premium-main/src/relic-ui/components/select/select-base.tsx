import { Interpolation, Theme } from "@emotion/react";
import React, { RefAttributes, useEffect } from "react";
import Select, { SingleValue } from "react-select";
import { getAppColorsString } from "../../theme/theme";
import { RelicInputRef } from "../input/input-base.types";
import type { Props as SelectProps } from "react-select";
import { removeKeys } from "../../utils/misc";

///
// export type SelectProps = {
//   options: { value: string; label: string }[];
//   placeholder?: string;
//   className?: string;
//   disabled?: boolean;
//   onChange?: (
//     value: SingleValue<{
//       value: string;
//       label: string;
//     }>
//   ) => void;
//   value?: SingleValue<{
//     value: string;
//     label: string;
//   }>;
// };

// export type CombinedRelicInputProps = SelectProps & RelicInputProps;

///
///
///

const _props = {
  px: undefined as number | undefined,
  py: undefined as number | undefined,
  bgColor: undefined as string | undefined,
  fgColor: undefined as string | undefined,
  hoverBgColor: undefined as string | undefined,
  hoverFgColor: undefined as string | undefined,

  leftIcon: undefined as React.ReactNode | undefined,
  rightIcon: undefined as React.ReactNode | undefined,
  alwaysShowRightIcon: undefined as boolean | undefined,

  rounded: undefined as number | undefined,
  fullWidth: undefined as boolean | undefined,
  disabled: undefined as boolean | undefined,
  //
  validator: undefined as ((value: string) => string | void) | undefined,
  label: undefined as string | undefined,
  onSubmit: undefined as ((value: string) => void) | undefined,
};

export type RelicSelectProps = Partial<typeof _props>;

export type RelicSelectPropsMixed = SelectProps & RelicSelectProps;

///
///
///

export const SelectBase = React.forwardRef<
  RelicInputRef<any>,
  RelicSelectPropsMixed
>((props, ref) => {
  const selectProps = removeKeys<RelicSelectPropsMixed>(props, _props);

  ///
  ///
  ///

  const [selectedOption, setSelectedOption] = React.useState<
    | SingleValue<{
        value: string;
        label: string;
      }>
    | undefined
  >(props.value as any);

  const [labelShown, setLabelShown] = React.useState(!!selectedOption);
  const [error, setError] = React.useState<string | null>(null);

  React.useImperativeHandle(ref, () => ({
    get value() {
      return selectedOption?.value ?? "";
    },
    set value(value) {
      if (typeof value === "object") {
        setSelectedOption(value);
      }
    },
    get numberValue() {
      return parseFloat(selectedOption?.value ?? "0");
    },
    get element() {
      return null;
    },
    validate() {
      setError(null);
      if (selectedOption) {
        let res: string | null = null;
        if (props.disabled) {
          return true;
        }
        if (props.validator) {
          const r = props.validator(selectedOption.value);
          if (r) {
            res = r;
          }
        }
        if (res == null) {
          return true;
        }
        setError(res);
        return false;
      }
      setError("Please select an option");
      return false;
    },
    setError(error: string | null) {
      setError(error);
    },
  }));

  //   useEffect(() => {
  //     if (props.value) {
  //       setSelectedOption(props.value as any);
  //     }
  //   }, [props.value]);

  return (
    <div
      className={`
        transition-all relative  pt-4 
          ${labelShown ? "" : ""}
            ${props.className || ""}

            ${
              props.disabled
                ? "opacity-70 pointer-events-none select-none "
                : ""
            }
        `}
    >
      <div
        className={`px-2 py-[6px] rounded-md
      bg-surface20 text-onSurfaceVariant
      outline-none border-2 
      focus-within:border-surfaceVariant60
      border-surfaceVariant40
      transition-all flex items-center space-x-2 w-full
      `}
      >
        {props.leftIcon}
        <Select
          {...selectProps}
          closeMenuOnSelect
          menuShouldScrollIntoView
          styles={{
            control: (provided, state) => ({
              ...provided,
              background: "transparent",
              border: "none",
              boxShadow: "none",
              outline: "none",
              padding: 0,
              minHeight: 0,
            }),
            valueContainer: (provided, state) => ({
              ...provided,
              padding: 0,
              color: getAppColorsString().onSurfaceVariant,
            }),
            placeholder: (provided, state) => ({
              ...provided,
              color: getAppColorsString().surfaceVariant60,
            }),
            input: (provided, state) => ({
              ...provided,
              padding: 0,
              margin: 0,
              color: getAppColorsString().onSurfaceVariant,
            }),
            singleValue: (provided, state) => ({
              ...provided,
              color: getAppColorsString().onSurface,
            }),
            indicatorsContainer: (provided, state) => ({
              ...provided,
              padding: 0,
            }),
            indicatorSeparator: (provided, state) => ({
              ...provided,
              padding: 0,
              backgroundColor: getAppColorsString().outline,
              width: 0,
              height: 0,
            }),
            dropdownIndicator: (provided, state) => ({
              ...provided,
              padding: 0,
            }),
            menu: (provided, state) => ({
              ...provided,
              background: getAppColorsString().surface,
              color: getAppColorsString().onSurface,
            }),
            option: (provided, state) => ({
              ...provided,
              //   ":hover": {
              //     background: getAppColors().surface40,
              //   },
              background: getAppColorsString().surface,
              color: getAppColorsString().onSurface,

              ...(state.isFocused && {
                background: getAppColorsString().surface40,
              }),

              ...(state.isSelected && {
                background: getAppColorsString().surfaceVariant40,
              }),

              ":active": {
                background: getAppColorsString().surfaceVariant40,
              },
            }),
          }}
          className={`bg-transparent outline-none transition-all
             placeholder:text-surfaceVariant60 placeholder:opacity-80 w-full
            `}
          placeholder={labelShown ? props.placeholder : ""}
          value={selectedOption}
          onChange={(e, a) => {
            setSelectedOption(e as any);
            const val = e;
            if (props.label) {
              setLabelShown(!!val);
            }
            setError(null);
            props.onChange && props.onChange(e, a);
          }}
          onFocus={(e) => {
            if (props.label) {
              setLabelShown(true);
            }
            // props.onFocus && props.onFocus(e);
          }}
          onBlur={(e) => {
            if (props.label) {
              setLabelShown(!!selectedOption);
            }
            // props.onBlur && props.onBlur(e);
          }}
        />
        {labelShown && props.rightIcon}
      </div>
      <label
        className={[
          `absolute top-0 flex items-center text-surfaceVariant60 opacity-90
              transition-all duration-200 ease-in-out pointer-events-none`,
          labelShown
            ? "text-xs left-1 "
            : `text-sm  pt-[25px] ${props.leftIcon ? "left-8" : "left-3"} `,
        ].join(" ")}
      >
        {props.label}
      </label>
      {error && <div className="text-xs px-1 text-error mt-[2px]">{error}</div>}
    </div>
  );
});
