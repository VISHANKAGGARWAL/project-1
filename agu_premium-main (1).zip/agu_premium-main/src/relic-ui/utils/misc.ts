/**
 *
 * @param obj Orginal object from which keys will be removed
 * @param keysObject Dummy object with keys to be removed from original object
 * @returns A new object with keys removed
 *
 * Used to remove keys from an object without mutating the original object
 */
/* eslint-disable @typescript-eslint/no-explicit-any */
export function removeKeys<T>(obj: T, keysObject: { [key: string]: any }) {
  const newObj = { ...obj };
  for (const key in keysObject) {
    delete (newObj as any)[key];
  }
  return newObj;
}
