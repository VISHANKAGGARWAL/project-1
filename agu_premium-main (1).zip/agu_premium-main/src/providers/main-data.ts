import { InventoryProduct } from "../_pages/seller/seller/providers/products/product-data";
import { useFirebaseDocCRUD } from "../core/firebase/providers-hook-new";

export const useGetBannerData = () => {
  const banner = useFirebaseDocCRUD<{
    bannerProduct: string;
  }>(`main/banner`, true);
  return banner;
};

export const useBannerProduct = () => {
  const bannerData = useGetBannerData();

  const bannerProduct = useFirebaseDocCRUD<InventoryProduct>(
    bannerData.data?.bannerProduct ?? "main/m",
    bannerData.data !== undefined
  );

  return {
    ...bannerProduct,
    loading: bannerProduct.loading || bannerData.loading,
  };
};
