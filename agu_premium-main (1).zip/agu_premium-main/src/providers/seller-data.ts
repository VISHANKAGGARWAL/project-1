import { useFireCollectionCRUD } from "../core/firebase/providers-hook-new";

export const useGetAllSellers = () => {
  const sellers = useFireCollectionCRUD<{
    id: string;
  }>(`seller`, true);
  return sellers;
};
