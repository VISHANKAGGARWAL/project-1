import { atom } from "jotai";
import {
  InventoryProduct,
  InventoryProductWithSeller,
} from "../_pages/seller/seller/providers/products/product-data";
import React from "react";
import { atomWithStorage } from "jotai/utils";

export interface Cart {
  items: InventoryProductWithSeller[];
}

export const cartAtom = atomWithStorage<Cart>("cart", {
  items: [],
});

const cartAtomContext = React.createContext(cartAtom);

export const useCartAtom = () => React.useContext(cartAtomContext);

export const CartAtomProvider = cartAtomContext.Provider;
